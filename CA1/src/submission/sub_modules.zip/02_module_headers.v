// Task-2 interface declarations only. No functional RTL.

module fcnn_accumulator_bank #(
    parameter integer N_HIDDEN=8, N_OUTPUTS=10
) (
    clk,
    rst,
    run_init,
    layer_sel,
    product_valid,
    product_ready,
    product_data,
    product_dest,
    product_last,
    bias_neuron,
    fc1_bias,
    fc2_biases,
    add_a,
    add_b,
    add_result,
    add_commit,
    fc1_final_valid,
    fc1_final_value,
    fc1_final_idx,
    fc2_all_committed,
    fc2_results
);
    
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer O_W=(N_OUTPUTS>1)?$clog2(N_OUTPUTS):1;
    localparam integer MAX_NEURONS=(N_HIDDEN>N_OUTPUTS)?N_HIDDEN:N_OUTPUTS;
    localparam integer DEST_W=(MAX_NEURONS>1)?$clog2(MAX_NEURONS):1;

    
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire layer_sel;
    input wire product_valid;
    output wire product_ready;
    input wire [15:0] product_data;
    input wire [DEST_W-1:0] product_dest;
    input wire product_last;
    output wire [H_W-1:0] bias_neuron;
    input wire [15:0] fc1_bias;
    input wire [16*N_OUTPUTS-1:0] fc2_biases;
    output wire [15:0] add_a;
    output wire [15:0] add_b;
    input wire [15:0] add_result;
    output wire add_commit;
    output wire fc1_final_valid;
    output wire [15:0] fc1_final_value;
    output wire [H_W-1:0] fc1_final_idx;
    output wire fc2_all_committed;
    output wire [16*N_OUTPUTS-1:0] fc2_results;
endmodule

module fcnn_activation_regfile #(
    parameter integer N_HIDDEN=8, N_OUTPUTS=10
) (
    clk,
    rst,
    run_init,
    hidden_wr_en,
    hidden_wr_idx,
    hidden_wr_data,
    hidden_rd_idx,
    hidden_rd_data,
    hidden_all_valid,
    final_wr_en,
    final_wr_data,
    final_ready,
    logits
);
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer RF_DEPTH=(N_HIDDEN>N_OUTPUTS)?N_HIDDEN:N_OUTPUTS;
    

    
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire hidden_wr_en;
    input wire [H_W-1:0] hidden_wr_idx;
    input wire [15:0] hidden_wr_data;
    input wire [H_W-1:0] hidden_rd_idx;
    output wire [15:0] hidden_rd_data;
    output wire hidden_all_valid;
    input wire final_wr_en;
    input wire [16*N_OUTPUTS-1:0] final_wr_data;
    output reg final_ready;
    output wire [16*N_OUTPUTS-1:0] logits;
endmodule

module fcnn_address_generator #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7
) (
    clk,
    rst,
    run_init,
    request_layer,
    advance_row,
    fc1_neuron,
    fc1_row,
    fc2_row,
    weight_addr,
    input_addr,
    weight_meta,
    input_meta
);
    
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer R1_W=(FC1_ROWS>1)?$clog2(FC1_ROWS):1;
    localparam integer R2_W=(FC2_ROWS>1)?$clog2(FC2_ROWS):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer META_W=1+H_W+ROW_W;
    localparam integer ADDR_W=(N_HIDDEN*FC1_ROWS+FC2_ROWS>1)?$clog2(N_HIDDEN*FC1_ROWS+FC2_ROWS):1;

    
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire request_layer;
    input wire advance_row;
    output wire [H_W-1:0] fc1_neuron;
    output wire [R1_W-1:0] fc1_row;
    output wire [R2_W-1:0] fc2_row;
    output wire [ADDR_W-1:0] weight_addr;
    output wire [R1_W-1:0] input_addr;
    output wire [META_W-1:0] weight_meta;
    output wire [META_W-1:0] input_meta;
endmodule

module fcnn_argmax #(parameter integer N_OUTPUTS=10) (
    logits,
    logits_valid,
    predicted_digit,
    argmax_valid
);
    localparam integer INDEX_W=(N_OUTPUTS>1)?$clog2(N_OUTPUTS):1;
    localparam integer LEAVES=2**$clog2(N_OUTPUTS);
    
    

    
    input wire [16*N_OUTPUTS-1:0] logits;
    input wire logits_valid;
    output wire [INDEX_W-1:0] predicted_digit;
    output wire argmax_valid;
endmodule

module fcnn_bias_rom #(
    parameter integer N_HIDDEN=8, N_OUTPUTS=10,
    parameter FC1_BIAS_FILE="fc1_bias.mem", FC2_BIAS_FILE="fc2_bias.mem"
) (
    fc1_neuron,
    fc1_bias,
    fc2_biases
);
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    

    
    input wire [H_W-1:0] fc1_neuron;
    output wire [15:0] fc1_bias;
    output wire [16*N_OUTPUTS-1:0] fc2_biases;
endmodule

module fcnn_controller (
    input wire clk, input wire rst, input wire start,
    input wire fc1_finished, input wire fc2_finished,
    output wire run_init, output wire fc1_active, output wire fc2_active,
    output wire busy, output wire done
);
endmodule

module fcnn_datapath #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7, SRAM_LATENCY=7,
    parameter FC1_WEIGHTS_FILE="fc1_weights.mem", FC2_WEIGHTS_FILE="fc2_weights.mem",
    parameter INPUT_FILE="test_image.mem", FC1_BIAS_FILE="fc1_bias.mem", FC2_BIAS_FILE="fc2_bias.mem"
) (
    clk,
    rst,
    run_init,
    fc1_active,
    fc2_active,
    fc1_finished,
    fc2_finished,
    logits,
    predicted_digit
);
    
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer INDEX_W=(N_OUTPUTS>1)?$clog2(N_OUTPUTS):1;
    localparam integer MAX_NEURONS=(N_HIDDEN>N_OUTPUTS)?N_HIDDEN:N_OUTPUTS;
    localparam integer DEST_W=(MAX_NEURONS>1)?$clog2(MAX_NEURONS):1;
    localparam integer R1_W=(FC1_ROWS>1)?$clog2(FC1_ROWS):1;
    localparam integer R2_W=(FC2_ROWS>1)?$clog2(FC2_ROWS):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer META_W=1+H_W+ROW_W;
    localparam integer ADDR_W=(N_HIDDEN*FC1_ROWS+FC2_ROWS>1)?$clog2(N_HIDDEN*FC1_ROWS+FC2_ROWS):1;
    localparam integer LANE_W=(LANES>1)?$clog2(LANES):1;

    
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire fc1_active;
    input wire fc2_active;
    output wire fc1_finished;
    output wire fc2_finished;
    output wire [16*N_OUTPUTS-1:0] logits;
    output wire [INDEX_W-1:0] predicted_digit;
endmodule

module fcnn_fp16_adder (
    input wire [15:0] a,
    input wire [15:0] b,
    output wire [15:0] result
);
endmodule

module fcnn_fp16_multiplier (
    input wire [15:0] a,
    input wire [15:0] b,
    output wire [15:0] result
);
endmodule

module fcnn_local_scheduler #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7
) (
    clk,
    rst,
    run_init,
    fc1_active,
    fc2_active,
    request_neuron,
    request_fc1_row,
    request_fc2_row,
    weight_available,
    input_available,
    compute_layer,
    compute_row,
    product_ready,
    pp_wr_ready,
    term_last,
    hidden_all_valid,
    activation_last_use,
    fc2_all_committed,
    final_ready,
    argmax_valid,
    request_layer,
    weight_req,
    input_req,
    consume_weight_row,
    consume_input_row,
    lane_idx,
    mul_issue,
    group_last,
    rf_final_we,
    fc1_finished,
    fc2_finished
);
    
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer R1_W=(FC1_ROWS>1)?$clog2(FC1_ROWS):1;
    localparam integer R2_W=(FC2_ROWS>1)?$clog2(FC2_ROWS):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer LANE_W=(LANES>1)?$clog2(LANES):1;
    localparam integer WAIT_W=$clog2(2*LANES+4);
    
    localparam integer PHASE_EDGES=3;
    localparam integer FC1_TAIL=N_INPUTS-(FC1_ROWS-1)*LANES;
    localparam integer FC2_TAIL=N_HIDDEN*N_OUTPUTS-(FC2_ROWS-1)*LANES;

    
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire fc1_active;
    input wire fc2_active;
    input wire [H_W-1:0] request_neuron;
    input wire [R1_W-1:0] request_fc1_row;
    input wire [R2_W-1:0] request_fc2_row;
    input wire weight_available;
    input wire input_available;
    input wire compute_layer;
    input wire [ROW_W-1:0] compute_row;
    input wire product_ready;
    input wire pp_wr_ready;
    input wire term_last;
    input wire hidden_all_valid;
    input wire activation_last_use;
    input wire fc2_all_committed;
    input wire final_ready;
    input wire argmax_valid;
    output wire request_layer;
    output wire weight_req;
    output wire input_req;
    output wire consume_weight_row;
    output wire consume_input_row;
    output wire [LANE_W-1:0] lane_idx;
    output wire mul_issue;
    output wire group_last;
    output wire rf_final_we;
    output wire fc1_finished;
    output wire fc2_finished;
endmodule

module fcnn_operand_router #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7
) (
    weight_row,
    input_row,
    weight_meta,
    input_meta,
    lane_idx,
    hidden_value,
    hidden_rd_idx,
    mul_weight,
    mul_input,
    term_valid,
    term_dest,
    term_last,
    activation_last_term
);
    
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer MAX_NEURONS=(N_HIDDEN>N_OUTPUTS)?N_HIDDEN:N_OUTPUTS;
    localparam integer DEST_W=(MAX_NEURONS>1)?$clog2(MAX_NEURONS):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer META_W=1+H_W+ROW_W;
    localparam integer LANE_W=(LANES>1)?$clog2(LANES):1;
    localparam integer FC2_MAIN=N_OUTPUTS*(N_HIDDEN-1);

    
    input wire [16*LANES-1:0] weight_row;
    input wire [16*LANES-1:0] input_row;
    input wire [META_W-1:0] weight_meta;
    input wire [META_W-1:0] input_meta;
    input wire [LANE_W-1:0] lane_idx;
    input wire [15:0] hidden_value;
    output wire [H_W-1:0] hidden_rd_idx;
    output wire [15:0] mul_weight;
    output wire [15:0] mul_input;
    output wire term_valid;
    output wire [DEST_W-1:0] term_dest;
    output wire term_last;
    output wire activation_last_term;
endmodule

module fcnn_ping_pong_buffer #(
    parameter integer LANES=7, DEST_W=4
) (
    input wire clk, input wire rst,
    input wire wr_valid, output wire wr_ready,
    input wire [15:0] wr_data, input wire [DEST_W-1:0] wr_dest,
    input wire wr_last, input wire wr_group_last,
    output wire rd_valid, input wire rd_ready,
    output wire [15:0] rd_data, output wire [DEST_W-1:0] rd_dest,
    output wire rd_last,
    output wire [1:0] bank_full, output wire [1:0] bank_empty,
    output wire bank_select
);
endmodule

module fcnn_product_register #(parameter integer DEST_W=4) (
    input wire clk, input wire rst,
    input wire in_valid, output wire in_ready,
    input wire [15:0] in_data, input wire [DEST_W-1:0] in_dest,
    input wire in_last, input wire in_group_last,
    output reg out_valid, input wire out_ready,
    output reg [15:0] out_data, output reg [DEST_W-1:0] out_dest,
    output reg out_last, output reg out_group_last
);
endmodule

module fcnn_relu_fp16 (input wire [15:0] x, output wire [15:0] y);
endmodule

module fcnn_row_sram #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7,
    parameter integer SRAM_LATENCY=7, SOURCE_KIND=1,
    parameter INIT_FILE="fc1_weights.mem", FC2_WEIGHTS_FILE="fc2_weights.mem"
) (
    clk,
    rst,
    req_valid,
    req_addr,
    req_meta,
    row_valid,
    row_data,
    row_meta
);
    
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer DEPTH=(SOURCE_KIND==1) ? N_HIDDEN*FC1_ROWS+FC2_ROWS : FC1_ROWS;
    localparam integer ADDR_W=(DEPTH>1)?$clog2(DEPTH):1;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer META_W=1+H_W+ROW_W;
    localparam integer FC2_MAIN=N_OUTPUTS*(N_HIDDEN-1);

    
    input wire clk;
    input wire rst;
    input wire req_valid;
    input wire [ADDR_W-1:0] req_addr;
    input wire [META_W-1:0] req_meta;
    output wire row_valid;
    output wire [16*LANES-1:0] row_data;
    output wire [META_W-1:0] row_meta;
endmodule

module fcnn_row_stage #(
    parameter integer LANES=7, META_W=12
) (
    input wire clk, input wire rst,
    input wire in_valid, input wire [16*LANES-1:0] in_data,
    input wire [META_W-1:0] in_meta, input wire consume_row,
    output wire can_accept, output reg stored_valid,
    output reg [16*LANES-1:0] stored_data, output reg [META_W-1:0] stored_meta
);
endmodule

module fcnn_top #(
    parameter integer N_INPUTS = 784,
    parameter integer N_HIDDEN = 8,
    parameter integer N_OUTPUTS = 10,
    parameter integer LANES = 7,
    parameter integer SRAM_LATENCY = 7,
    parameter FC1_WEIGHTS_FILE = "fc1_weights.mem",
    parameter FC2_WEIGHTS_FILE = "fc2_weights.mem",
    parameter INPUT_FILE = "test_image.mem",
    parameter FC1_BIAS_FILE = "fc1_bias.mem",
    parameter FC2_BIAS_FILE = "fc2_bias.mem"
) (
    input wire clk, input wire rst, input wire start,
    output wire busy, output wire done,
    output wire [16*N_OUTPUTS-1:0] logits,
    output wire [((N_OUTPUTS>1)?$clog2(N_OUTPUTS):1)-1:0] predicted_digit
);
endmodule
