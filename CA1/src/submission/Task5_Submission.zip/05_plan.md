# برنامه بازآرایی و پیاده‌سازی FCNN

این برنامه پیش از اصلاح RTL نوشته شد. نسخه مبنا همان ZIP ارسالی کاربر است.

1. پورت بیرونی Top و تفکیک Controller/Datapath حفظ می‌شود. ابعاد شبکه، تعداد laneها، تأخیر SRAM، هر پنج مسیر فایل از Top به زیرماژول‌ها ارسال می‌شوند. عرض‌های آدرس و متادیتا از ابعاد محاسبه می‌شوند. قالب binary16 و RNE جزو قرارداد عددی‌اند، نه گزینه قابل تغییر عرض.
2. فقط AddressGenerator شمارنده آدرس دارد. Scheduler از شمارنده‌های آن استفاده می‌کند؛ فاز درخواست و فاز محاسبه مستقل و صریح‌اند. فاصله درخواست از طول ردیف، بسته‌شدن بانک و تأخیر پایپ‌لاین مشتق می‌شود. توقف غیرمنتظره خطای قرارداد است؛ رجیستر اضطراری افزوده نمی‌شود.
3. SRAM نوع وزن/تصویر را با پارامتر صریح می‌گیرد، نه با حدس از DEPTH. فایل‌ها اسکالر 16 بیتی باقی می‌مانند. FC2 ابتدا همه ورودی‌ها به جز آخری را به ترتیب مقصد و سپس ورودی آخر تمام مقصدها مصرف می‌کند.
4. ProductRegister و دو بانک Ping-Pong با valid/ready کار می‌کنند. متادیتا همراه داده می‌ماند. دو بانک هر کدام LANES خانه دارند؛ padding گروه آخر مصرف نمی‌شود. Cut-through نسخه قبلی حذف می‌شود؛ خواندن تنها از بانک تکمیل‌شده مجاز است. seal و حساب همزمان push/pop حفظ می‌شوند.
5. تنها یک نمونه MUL و یک نمونه ADD موجود است. مطابق PDF با همان ADD بایاس پس از آخرین محصول جمع می‌شود؛ Scheduler فاصله لازم را رزرو می‌کند.
6. RF با max(N_HIDDEN,N_OUTPUTS) خانه پس از آخرین خواندن hidden برای logits بازاستفاده می‌شود؛ overwrite زودرس و اتمام ناقص بررسی می‌شود.
7. TB شامل taskهای reset/start/run/check، پارامترهای Top، scoreboard مستقل ترتیب عملیات، مقایسه تمام hidden/logitها، timeout، restart و reset وسط کار خواهد بود. Python مدل مستقل استاندارد-library FP16، اجرای Icarus/ModelSim و گزارش JSON فراهم می‌کند.
8. هر ماژول پلن هم‌نام و Stepهای متناظر دارد. تصاویر hierarchy/datapath/FSM از RTL و مشخصات جاری ساخته می‌شوند. کد و پلن تجمیع تکراری، هش‌های کهنه و مدل‌های تکراری حذف می‌شوند.
9. ابتدا baseline اجرا می‌شود. سپس regression داده‌های اصلی، تست عددی، واحدها، تغییر ابعاد/latency، restart/reset و تست‌های منفی اجرا می‌شوند. نتیجه ModelSim فقط در صورت اجرای واقعی آن ادعا می‌شود.

اصلاح برنامه پیش از تکمیل پیاده‌سازی: کاربر صریحاً دو PDF صورت پروژه را بر تصمیم‌های قبلی اولویت داد؛ بنابراین bias-first و cut-through هیچ‌کدام جزو RTL نهایی نیستند.

اصلاح پس از دریافت لاگ ModelSim 2020.1: رابط ۹ ماژول به اعلان non-ANSI تبدیل شد تا localparamهای عرض قبل از اعلان نوع پورت‌ها قرار بگیرند. پارامترهای عمومی، قرارداد پورت‌ها و منطق اجرایی حفظ شدند. تولید مستندات و headerهای تسک۲ اکنون هر دو سبک اعلان را می‌خواند و استفاده زودهنگام از ثابت عرض را رد می‌کند. شرح و نتیجه بازآزمایی در `MODELSIM_2020_FIX_FA.md` ثبت شده است.

تکمیل مسیر ارائه در GUI: تنظیمات ورودی و سناریو در ابتدای همان TB قرار گرفت. پیش‌فرض TB از فایل‌های موجود پروژه اجرا می‌شود و golden/plusarg اجباری ندارد؛ بررسی عددی با `CHECK_OUTPUTS` مستقل و صریح فعال می‌شود. `run_modelsim.do` بدون Python، کامپایل و بارگذاری و ثبت ۸۷ سیگنال مرتب‌شده را انجام می‌دهد. پس از پایان موفق، کلاک TB متوقف می‌شود و طراحی برای مشاهده Wave بارگذاری‌شده می‌ماند. همه تغییرها در TB/ابزارها هستند و RTL محاسبات تغییر نمی‌کند.


---

# برنامه جاری fcnn_accumulator_bank

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_accumulator_bank.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 1 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_HIDDEN`, `N_OUTPUTS`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. one FC1 accumulator and N_OUTPUTS FC2 accumulators, initially zero.
2. the SAME adder handles products and, one edge later, final bias.
3. look ahead at the final bias commit, including its live result.
4. finalize each neuron only after its separate final bias operation.


---

# برنامه جاری fcnn_activation_regfile

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_activation_regfile.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 1 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_HIDDEN`, `N_OUTPUTS`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. reuse one RF; no duplicate hidden/output storage array.
2. validity clears for each run; reset also clears RF payload.
3. asynchronous read and parallel packed logits, index zero in LSBs.


---

# برنامه جاری fcnn_address_generator

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_address_generator.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 1 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_INPUTS`, `N_HIDDEN`, `N_OUTPUTS`, `LANES`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. one owner for request progress; Scheduler reads these counters.
2. advance exactly once per accepted request.
3. physical row addresses. Metadata = {layer, hidden_neuron, row}.


---

# برنامه جاری fcnn_argmax

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_argmax.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 0 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_OUTPUTS`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. balanced tree size; local node wires avoid array feedback warnings.
2. numerical FP16 order; first index wins ties and all-NaN inputs.
3. validity gates prediction until the RF contains final logits.


---

# برنامه جاری fcnn_bias_rom

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_bias_rom.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 0 ترتیبی، 0 ترکیبی، 1 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_HIDDEN`, `N_OUTPUTS`, `FC1_BIAS_FILE`, `FC2_BIAS_FILE`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. independent scalar bias ROMs.
2. FC1 is indexed by the backend destination, never request progress.


---

# برنامه جاری fcnn_controller

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_controller.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 1 ترتیبی، 1 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: ندارد. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. the four phases are protocol states, not tunable parameters.
2. synchronous active-high reset.
3. start is accepted only in IDLE; busy starts are ignored.
4. DONE lasts one cycle. A held start is accepted on returning IDLE.


---

# برنامه جاری fcnn_datapath

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_datapath.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 0 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_INPUTS`, `N_HIDDEN`, `N_OUTPUTS`, `LANES`, `SRAM_LATENCY`, `FC1_WEIGHTS_FILE`, `FC2_WEIGHTS_FILE`, `INPUT_FILE`, `FC1_BIAS_FILE`, `FC2_BIAS_FILE`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. derived sizes and named interconnect. No user configuration here.
2. request address ownership and the two synchronous SRAM row paths.
3. Scheduler controls handshakes; Router owns arithmetic operand tags.
4. the only FP16 multiplier; registered products enter two-bank PP.
5. the only FP16 adder; the backend mux schedules the separate bias.
6. ReLU -> reused RF -> balanced parallel argmax.
7. local contracts cover phase/tag errors and premature RF reuse.


---

# برنامه جاری fcnn_fp16_adder

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_fp16_adder.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 0 ترتیبی، 1 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: ندارد. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. Unpacking, Classification & Magnitude Compare (باز کردن بسته‌بندی، طبقه‌بندی و مقایسه اندازه)
2. Operand Swapping & Mantissa Alignment (مرتب‌سازی عملوندها و تراز کردن مانتیس‌ها)
3. Mantissa Addition / Subtraction (جمع یا تفریق مانتیس‌های تراز شده)
4. Normalization & LZC (نرمال‌سازی، شمارش صفرهای پیشرو و مدیریت Gradual Underflow)
5. RNE Rounding & Post-Normalization (گرد کردن به نزدیک‌ترین زوج)
6. Exception Handling & Output Muxing (مدیریت استثناها و انتخاب خروجی نهایی)


---

# برنامه جاری fcnn_fp16_multiplier

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_fp16_multiplier.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 0 ترتیبی، 2 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: ندارد. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. Unpacking & Classification (باز کردن بسته‌بندی ورودی‌ها و تشخیص حالات خاص)
2. Input Pre-Normalization (نرمال‌سازی عملوندهای ورودی Subnormal)
3. Core Multiplication & Exponent Calculation (ضرب مانتیس ۱۱×۱۱ و محاسبه نمای اولیه)
4. Alignment & GRS Extraction (مدیریت Gradual Underflow و استخراج بیت‌های GRS)
5. RNE Rounding & Post-Normalization (گرد کردن به نزدیک‌ترین زوج)
6. Exception Handling & Output Muxing (مدیریت استثناها و انتخاب خروجی نهایی)


---

# برنامه جاری fcnn_local_scheduler

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_local_scheduler.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 1 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_INPUTS`, `N_HIDDEN`, `N_OUTPUTS`, `LANES`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. control progress, not duplicated address counters.
2. reserve responses at the exact consumption cadence.
3. completion derives from committed values and last activation read.
4. an unexpected stall invalidates the single-row calendar.


---

# برنامه جاری fcnn_operand_router

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_operand_router.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 0 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_INPUTS`, `N_HIDDEN`, `N_OUTPUTS`, `LANES`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. decode request metadata independently of the current request phase.
2. all but the final hidden input, then final input across outputs.
3. the hidden address has no combinational dependence on hidden data.


---

# برنامه جاری fcnn_ping_pong_buffer

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_ping_pong_buffer.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 1 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `LANES`, `DEST_W`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. two physical banks. Pointer width includes the full sentinel.
2. seal prevents reopening even a partially filled undrained bank.
3. write and seal a group (including a short final group).
4. read only a completed bank; release on its group terminator.
5. simultaneous push/pop has a net occupancy change of zero.


---

# برنامه جاری fcnn_product_register

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_product_register.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 1 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `DEST_W`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. one elastic payload register, including every sideband bit.
2. replace on ready, clear valid on a pop without a replacement.


---

# برنامه جاری fcnn_relu_fp16

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_relu_fp16.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 0 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: ندارد. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. canonicalize any NaN; map every non-NaN negative to positive zero.


---

# برنامه جاری fcnn_row_sram

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_row_sram.v`؛ نمونه‌ها در hierarchy: 2.

بلوک‌های عملکردی: 1 ترتیبی، 0 ترکیبی، 2 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_INPUTS`, `N_HIDDEN`, `N_OUTPUTS`, `LANES`, `SRAM_LATENCY`, `SOURCE_KIND`, `INIT_FILE`, `FC2_WEIGHTS_FILE`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

برای سازگاری Verilog-2005 با ModelSim 2020، فهرست پورت‌ها non-ANSI است؛ ثابت‌های مشتق قبل از اعلان نوع و عرض پورت‌ها قرار دارند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. layout and widths derive only from network parameters.
2. raw files stay 16-bit/neuron-major; rows are assembled inside SRAM.
3. a request sampled at E is sampled downstream at E+SRAM_LATENCY.


---

# برنامه جاری fcnn_row_stage

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_row_stage.v`؛ نمونه‌ها در hierarchy: 2.

بلوک‌های عملکردی: 1 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `LANES`, `META_W`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. one row only; same-edge replacement does not allocate extra storage.
2. reset, accept/replace, consume, otherwise hold.
3. diagnose a calendar error rather than silently losing data.


---

# برنامه جاری fcnn_top

این برنامه با طرح بازآرایی `../05_plan.md` و Stepهای نسخه جاری کد همگام است.

RTL: `rtl/fcnn_top.v`؛ نمونه‌ها در hierarchy: 1.

بلوک‌های عملکردی: 0 ترتیبی، 0 ترکیبی، 0 initial. نگهبان‌های شبیه‌سازی در این شمارش عملکردی نیستند.

پارامترها: `N_INPUTS`, `N_HIDDEN`, `N_OUTPUTS`, `LANES`, `SRAM_LATENCY`, `FC1_WEIGHTS_FILE`, `FC2_WEIGHTS_FILE`, `INPUT_FILE`, `FC1_BIAS_FILE`, `FC2_BIAS_FILE`. عرض‌ها و عمق‌های مشتق با localparam محاسبه می‌شوند.

تخصیص به ثبات‌ها در لبه کلاک با `<=` و منطق ترکیبی با `assign` یا `=` انجام می‌شود. reset تمام ثبات‌های اعتبار سنکرون و فعال یک است؛ ROMها با reset بازنویسی نمی‌شوند.

1. the public configuration boundary. All user choices enter here.
2. control/status only; no arithmetic or storage in Top.
3. propagate every public setting by name.
4. configuration errors are explicit simulation failures.
