// Generated from rtl/files.f. Compile THIS file OR rtl/*.v, never both.

// Source: rtl/fcnn_accumulator_bank.v
`default_nettype none
module fcnn_accumulator_bank #(
    parameter integer N_HIDDEN=8, N_OUTPUTS=10
) (
    clk,
    rst,
    run_init,
    layer_sel,
    product_valid,
    product_ready,
    product_data,
    product_dest,
    product_last,
    bias_neuron,
    fc1_bias,
    fc2_biases,
    add_a,
    add_b,
    add_result,
    add_commit,
    fc1_final_valid,
    fc1_final_value,
    fc1_final_idx,
    fc2_all_committed,
    fc2_results
);
    // Step 1: one FC1 accumulator and N_OUTPUTS FC2 accumulators, initially zero.
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer O_W=(N_OUTPUTS>1)?$clog2(N_OUTPUTS):1;
    localparam integer MAX_NEURONS=(N_HIDDEN>N_OUTPUTS)?N_HIDDEN:N_OUTPUTS;
    localparam integer DEST_W=(MAX_NEURONS>1)?$clog2(MAX_NEURONS):1;

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire layer_sel;
    input wire product_valid;
    output wire product_ready;
    input wire [15:0] product_data;
    input wire [DEST_W-1:0] product_dest;
    input wire product_last;
    output wire [H_W-1:0] bias_neuron;
    input wire [15:0] fc1_bias;
    input wire [16*N_OUTPUTS-1:0] fc2_biases;
    output wire [15:0] add_a;
    output wire [15:0] add_b;
    input wire [15:0] add_result;
    output wire add_commit;
    output wire fc1_final_valid;
    output wire [15:0] fc1_final_value;
    output wire [H_W-1:0] fc1_final_idx;
    output wire fc2_all_committed;
    output wire [16*N_OUTPUTS-1:0] fc2_results;

    reg [15:0] fc1_acc;
    reg [15:0] fc2_acc[0:N_OUTPUTS-1];
    reg [N_OUTPUTS-1:0] committed;
    reg bias_pending;
    reg [DEST_W-1:0] pending_dest;
    wire [DEST_W-1:0] active_dest=bias_pending?pending_dest:product_dest;
    wire consume_product=product_valid && product_ready;
    // Step 2: the SAME adder handles products and, one edge later, final bias.
    assign product_ready=!bias_pending;
    assign bias_neuron=active_dest[H_W-1:0];
    assign add_a=layer_sel ? ((active_dest<N_OUTPUTS)?fc2_acc[active_dest[O_W-1:0]]:16'd0) : fc1_acc;
    assign add_b=bias_pending ?
        (layer_sel ? fc2_biases[16*active_dest+:16] : fc1_bias) : product_data;
    assign add_commit=bias_pending || consume_product;
    assign fc1_final_valid=!layer_sel && bias_pending;
    assign fc1_final_value=add_result;
    assign fc1_final_idx=active_dest[H_W-1:0];
    // Step 3: look ahead at the final bias commit, including its live result.
    wire [N_OUTPUTS-1:0] current_final=(layer_sel && bias_pending) ?
        ({{(N_OUTPUTS-1){1'b0}},1'b1}<<active_dest) : {N_OUTPUTS{1'b0}};
    assign fc2_all_committed=&(committed | current_final);
    genvar k;
    generate for (k=0;k<N_OUTPUTS;k=k+1) begin: g_result
        assign fc2_results[16*k+:16]=(layer_sel && add_commit && active_dest==k) ? add_result : fc2_acc[k];
    end endgenerate
    // Step 4: finalize each neuron only after its separate final bias operation.
    integer j;
    always @(posedge clk) begin
        if (rst || run_init) begin
            fc1_acc<=0; committed<=0; bias_pending<=0; pending_dest<=0;
            for (j=0;j<N_OUTPUTS;j=j+1) fc2_acc[j]<=0;
        end else begin
            if (bias_pending) begin
                bias_pending<=0;
                if (layer_sel) begin
                    fc2_acc[pending_dest[O_W-1:0]]<=add_result;
                    committed[pending_dest[O_W-1:0]]<=1;
                end else fc1_acc<=0;
            end else if (consume_product) begin
                if (layer_sel) fc2_acc[product_dest[O_W-1:0]]<=add_result;
                else fc1_acc<=add_result;
                if (product_last) begin bias_pending<=1;pending_dest<=product_dest;end
            end
            // synthesis translate_off
            if (consume_product && (layer_sel ? product_dest>=N_OUTPUTS : product_dest>=N_HIDDEN))
                begin $display("[FAIL] ACCUMULATOR invalid destination"); $finish; end
            // synthesis translate_on
        end
    end
endmodule
`default_nettype wire

// Source: rtl/fcnn_activation_regfile.v
`default_nettype none
module fcnn_activation_regfile #(
    parameter integer N_HIDDEN=8, N_OUTPUTS=10
) (
    clk,
    rst,
    run_init,
    hidden_wr_en,
    hidden_wr_idx,
    hidden_wr_data,
    hidden_rd_idx,
    hidden_rd_data,
    hidden_all_valid,
    final_wr_en,
    final_wr_data,
    final_ready,
    logits
);
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer RF_DEPTH=(N_HIDDEN>N_OUTPUTS)?N_HIDDEN:N_OUTPUTS;
    // Step 1: reuse one RF; no duplicate hidden/output storage array.

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire hidden_wr_en;
    input wire [H_W-1:0] hidden_wr_idx;
    input wire [15:0] hidden_wr_data;
    input wire [H_W-1:0] hidden_rd_idx;
    output wire [15:0] hidden_rd_data;
    output wire hidden_all_valid;
    input wire final_wr_en;
    input wire [16*N_OUTPUTS-1:0] final_wr_data;
    output reg final_ready;
    output wire [16*N_OUTPUTS-1:0] logits;

    reg [15:0] rf_mem[0:RF_DEPTH-1];
    reg [N_HIDDEN-1:0] hidden_mask;
    integer j;
    // Step 2: validity clears for each run; reset also clears RF payload.
    always @(posedge clk) begin
        if (rst) begin
            hidden_mask<=0;final_ready<=0;
            for (j=0;j<RF_DEPTH;j=j+1) rf_mem[j]<=0;
        end else if (run_init) begin
            hidden_mask<=0;final_ready<=0;
        end else if (final_wr_en) begin
            for (j=0;j<N_OUTPUTS;j=j+1) rf_mem[j]<=final_wr_data[16*j+:16];
            final_ready<=1;
        end else if (hidden_wr_en) begin
            rf_mem[hidden_wr_idx]<=hidden_wr_data;
            hidden_mask[hidden_wr_idx]<=1;
        end
        // synthesis translate_off
        if (!rst && hidden_wr_en && final_wr_en)
            begin $display("[FAIL] RF conflicting hidden/final writes"); $finish; end
        // synthesis translate_on
    end
    // Step 3: asynchronous read and parallel packed logits, index zero in LSBs.
    assign hidden_rd_data=(hidden_rd_idx<N_HIDDEN)?rf_mem[hidden_rd_idx]:16'd0;
    assign hidden_all_valid=&hidden_mask;
    genvar k;
    generate for (k=0;k<N_OUTPUTS;k=k+1) begin: g_logits
        assign logits[16*k+:16]=rf_mem[k];
    end endgenerate
endmodule
`default_nettype wire

// Source: rtl/fcnn_address_generator.v
`default_nettype none
module fcnn_address_generator #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7
) (
    clk,
    rst,
    run_init,
    request_layer,
    advance_row,
    fc1_neuron,
    fc1_row,
    fc2_row,
    weight_addr,
    input_addr,
    weight_meta,
    input_meta
);
    // Step 1: one owner for request progress; Scheduler reads these counters.
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer R1_W=(FC1_ROWS>1)?$clog2(FC1_ROWS):1;
    localparam integer R2_W=(FC2_ROWS>1)?$clog2(FC2_ROWS):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer META_W=1+H_W+ROW_W;
    localparam integer ADDR_W=(N_HIDDEN*FC1_ROWS+FC2_ROWS>1)?$clog2(N_HIDDEN*FC1_ROWS+FC2_ROWS):1;

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire request_layer;
    input wire advance_row;
    output wire [H_W-1:0] fc1_neuron;
    output wire [R1_W-1:0] fc1_row;
    output wire [R2_W-1:0] fc2_row;
    output wire [ADDR_W-1:0] weight_addr;
    output wire [R1_W-1:0] input_addr;
    output wire [META_W-1:0] weight_meta;
    output wire [META_W-1:0] input_meta;

    reg [H_W-1:0] neuron_reg;
    reg [R1_W-1:0] row1_reg;
    reg [R2_W-1:0] row2_reg;
    wire [ROW_W-1:0] row1_meta=row1_reg, row2_meta=row2_reg;
    // Step 2: advance exactly once per accepted request.
    always @(posedge clk) begin
        if (rst || run_init) begin
            neuron_reg<=0; row1_reg<=0; row2_reg<=0;
        end else if (advance_row) begin
            if (!request_layer) begin
                if (row1_reg==FC1_ROWS-1) begin
                    row1_reg<=0;
                    case (neuron_reg)
                        N_HIDDEN-1: neuron_reg<=neuron_reg;
                        default: neuron_reg<=neuron_reg+1'b1;
                    endcase
                end else row1_reg<=row1_reg+1'b1;
            end else begin
                case (row2_reg)
                    FC2_ROWS-1: row2_reg<=row2_reg;
                    default: row2_reg<=row2_reg+1'b1;
                endcase
            end
        end
    end
    // Step 3: physical row addresses. Metadata = {layer, hidden_neuron, row}.
    wire [31:0] physical_addr = request_layer ? N_HIDDEN*FC1_ROWS+row2_reg : neuron_reg*FC1_ROWS+row1_reg;
    assign weight_addr = physical_addr[ADDR_W-1:0];
    assign input_addr = row1_reg;
    assign weight_meta = request_layer ? {1'b1, {H_W{1'b0}}, row2_meta} : {1'b0, neuron_reg, row1_meta};
    assign input_meta = {1'b0, neuron_reg, row1_meta};
    assign fc1_neuron=neuron_reg;
    assign fc1_row=row1_reg;
    assign fc2_row=row2_reg;
endmodule
`default_nettype wire

// Source: rtl/fcnn_argmax.v
`default_nettype none
module fcnn_argmax #(parameter integer N_OUTPUTS=10) (
    logits,
    logits_valid,
    predicted_digit,
    argmax_valid
);
    localparam integer INDEX_W=(N_OUTPUTS>1)?$clog2(N_OUTPUTS):1;
    localparam integer LEAVES=2**$clog2(N_OUTPUTS);
    // Step 1: balanced tree size; local node wires avoid array feedback warnings.
    // Step 2: numerical FP16 order; first index wins ties and all-NaN inputs.

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire [16*N_OUTPUTS-1:0] logits;
    input wire logits_valid;
    output wire [INDEX_W-1:0] predicted_digit;
    output wire argmax_valid;

    function keep_first;
        input [15:0] a,b;
        reg an,bn;
        begin
            an=(a[14:10]==5'h1f && a[9:0]!=0);
            bn=(b[14:10]==5'h1f && b[9:0]!=0);
            if (an || bn) keep_first=!an || bn;
            else if (a[14:0]==0 && b[14:0]==0) keep_first=1;
            else if (a[15]!=b[15]) keep_first=!a[15];
            else keep_first=a[15] ? a[14:0]<=b[14:0] : a[14:0]>=b[14:0];
        end
    endfunction
    genvar k;
    generate
        for (k=1;k<2*LEAVES;k=k+1) begin: tree
            wire [15:0] value;
            wire [INDEX_W-1:0] index;
            wire valid;
            if (k>=LEAVES) begin: leaf
                if (k-LEAVES<N_OUTPUTS) begin: present
                    assign value=logits[16*(k-LEAVES)+:16];
                    localparam [31:0] LEAF_INDEX=k-LEAVES;
                    assign index=LEAF_INDEX[INDEX_W-1:0];
                    assign valid=1;
                end else begin: padding
                    assign value=0;assign index=0;assign valid=0;
                end
            end else begin: branch
                wire left_wins=tree[2*k].valid && (!tree[2*k+1].valid ||
                    keep_first(tree[2*k].value,tree[2*k+1].value));
                assign value=left_wins ? tree[2*k].value : tree[2*k+1].value;
                assign index=left_wins ? tree[2*k].index : tree[2*k+1].index;
                assign valid=tree[2*k].valid || tree[2*k+1].valid;
            end
        end
    endgenerate
    // Step 3: validity gates prediction until the RF contains final logits.
    assign predicted_digit=logits_valid ? tree[1].index : {INDEX_W{1'b0}};
    assign argmax_valid=logits_valid;
endmodule
`default_nettype wire

// Source: rtl/fcnn_bias_rom.v
`default_nettype none
module fcnn_bias_rom #(
    parameter integer N_HIDDEN=8, N_OUTPUTS=10,
    parameter FC1_BIAS_FILE="fc1_bias.mem", FC2_BIAS_FILE="fc2_bias.mem"
) (
    fc1_neuron,
    fc1_bias,
    fc2_biases
);
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    // Step 1: independent scalar bias ROMs.

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire [H_W-1:0] fc1_neuron;
    output wire [15:0] fc1_bias;
    output wire [16*N_OUTPUTS-1:0] fc2_biases;

    reg [15:0] fc1_mem[0:N_HIDDEN-1], fc2_mem[0:N_OUTPUTS-1];
    initial begin
        $readmemh(FC1_BIAS_FILE,fc1_mem);
        $readmemh(FC2_BIAS_FILE,fc2_mem);
    end
    // Step 2: FC1 is indexed by the backend destination, never request progress.
    assign fc1_bias=(fc1_neuron<N_HIDDEN)?fc1_mem[fc1_neuron]:16'd0;
    genvar j;
    generate for (j=0;j<N_OUTPUTS;j=j+1) begin: g_bias
        assign fc2_biases[16*j+:16]=fc2_mem[j];
    end endgenerate
endmodule
`default_nettype wire

// Source: rtl/fcnn_controller.v
`default_nettype none
module fcnn_controller (
    input wire clk, input wire rst, input wire start,
    input wire fc1_finished, input wire fc2_finished,
    output wire run_init, output wire fc1_active, output wire fc2_active,
    output wire busy, output wire done
);
    // Step 1: the four phases are protocol states, not tunable parameters.
    localparam [1:0] IDLE=2'd0, FC1=2'd1, FC2=2'd2, DONE=2'd3;
    reg [1:0] state, next_state;
    // Step 2: synchronous active-high reset.
    always @(posedge clk) begin
        if (rst) state <= IDLE;
        else state <= next_state;
    end
    // Step 3: start is accepted only in IDLE; busy starts are ignored.
    always @(*) begin
        next_state = state;
        case (state)
            IDLE: if (start && !rst) next_state = FC1;
            FC1: if (fc1_finished) next_state = FC2;
            FC2: if (fc2_finished) next_state = DONE;
            DONE: next_state = IDLE;
            default: next_state = IDLE;
        endcase
    end
    // Step 4: DONE lasts one cycle. A held start is accepted on returning IDLE.
    assign run_init = (state==IDLE) && start && !rst;
    assign fc1_active = state==FC1;
    assign fc2_active = state==FC2;
    assign busy = fc1_active || fc2_active;
    assign done = state==DONE;
endmodule
`default_nettype wire

// Source: rtl/fcnn_datapath.v
`default_nettype none
module fcnn_datapath #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7, SRAM_LATENCY=7,
    parameter FC1_WEIGHTS_FILE="fc1_weights.mem", FC2_WEIGHTS_FILE="fc2_weights.mem",
    parameter INPUT_FILE="test_image.mem", FC1_BIAS_FILE="fc1_bias.mem", FC2_BIAS_FILE="fc2_bias.mem"
) (
    clk,
    rst,
    run_init,
    fc1_active,
    fc2_active,
    fc1_finished,
    fc2_finished,
    logits,
    predicted_digit
);
    // Step 1: derived sizes and named interconnect. No user configuration here.
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer INDEX_W=(N_OUTPUTS>1)?$clog2(N_OUTPUTS):1;
    localparam integer MAX_NEURONS=(N_HIDDEN>N_OUTPUTS)?N_HIDDEN:N_OUTPUTS;
    localparam integer DEST_W=(MAX_NEURONS>1)?$clog2(MAX_NEURONS):1;
    localparam integer R1_W=(FC1_ROWS>1)?$clog2(FC1_ROWS):1;
    localparam integer R2_W=(FC2_ROWS>1)?$clog2(FC2_ROWS):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer META_W=1+H_W+ROW_W;
    localparam integer ADDR_W=(N_HIDDEN*FC1_ROWS+FC2_ROWS>1)?$clog2(N_HIDDEN*FC1_ROWS+FC2_ROWS):1;
    localparam integer LANE_W=(LANES>1)?$clog2(LANES):1;

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire fc1_active;
    input wire fc2_active;
    output wire fc1_finished;
    output wire fc2_finished;
    output wire [16*N_OUTPUTS-1:0] logits;
    output wire [INDEX_W-1:0] predicted_digit;

    wire [H_W-1:0] request_neuron;
    wire [R1_W-1:0] request_fc1_row, input_addr;
    wire [R2_W-1:0] request_fc2_row;
    wire [ADDR_W-1:0] weight_addr;
    wire [META_W-1:0] weight_request_meta, input_request_meta;
    wire request_layer, weight_req, input_req, consume_weight_row, consume_input_row;
    wire [LANE_W-1:0] lane_idx;
    wire mul_issue, group_last;
    wire weight_sram_valid, input_sram_valid, weight_available, input_available;
    wire [16*LANES-1:0] weight_sram_data, input_sram_data, weight_stage_data, input_stage_data;
    wire [META_W-1:0] weight_sram_meta, input_sram_meta, weight_stage_meta, input_stage_meta;
    wire compute_layer=weight_stage_meta[META_W-1];
    wire [ROW_W-1:0] compute_row=weight_stage_meta[ROW_W-1:0];
    wire [H_W-1:0] hidden_rd_idx, bias_neuron, fc1_final_idx;
    wire [15:0] hidden_rd_data, mul_weight, mul_input, mul_result;
    wire term_valid, term_last, activation_last_term;
    wire [DEST_W-1:0] term_dest;
    wire product_ready, pp_wr_ready, pp_wr_valid, pp_wr_last, pp_wr_group_last;
    wire [15:0] pp_wr_data, pp_rd_data;
    wire [DEST_W-1:0] pp_wr_dest, pp_rd_dest;
    wire pp_rd_valid, pp_rd_ready, pp_rd_last;
    wire [15:0] add_a, add_b, add_result, fc1_bias, fc1_final_value, relu_out;
    wire [16*N_OUTPUTS-1:0] fc2_biases, fc2_results;
    wire add_commit, fc1_final_valid, hidden_all_valid, fc2_all_committed;
    wire rf_final_we, final_ready, argmax_valid;
    wire pipe_reset=rst || run_init;
    // Step 2: request address ownership and the two synchronous SRAM row paths.
    fcnn_address_generator #(
        .N_INPUTS(N_INPUTS),.N_HIDDEN(N_HIDDEN),.N_OUTPUTS(N_OUTPUTS),.LANES(LANES)
    ) address_inst (
        .clk(clk),.rst(rst),.run_init(run_init),.request_layer(request_layer),.advance_row(weight_req),
        .fc1_neuron(request_neuron),.fc1_row(request_fc1_row),.fc2_row(request_fc2_row),
        .weight_addr(weight_addr),.input_addr(input_addr),.weight_meta(weight_request_meta),.input_meta(input_request_meta)
    );
    fcnn_row_sram #(
        .N_INPUTS(N_INPUTS),.N_HIDDEN(N_HIDDEN),.N_OUTPUTS(N_OUTPUTS),.LANES(LANES),
        .SRAM_LATENCY(SRAM_LATENCY),.SOURCE_KIND(1),
        .INIT_FILE(FC1_WEIGHTS_FILE),.FC2_WEIGHTS_FILE(FC2_WEIGHTS_FILE)
    ) weight_sram_inst (
        .clk(clk),.rst(pipe_reset),.req_valid(weight_req),.req_addr(weight_addr),.req_meta(weight_request_meta),
        .row_valid(weight_sram_valid),.row_data(weight_sram_data),.row_meta(weight_sram_meta)
    );
    fcnn_row_sram #(
        .N_INPUTS(N_INPUTS),.N_HIDDEN(N_HIDDEN),.N_OUTPUTS(N_OUTPUTS),.LANES(LANES),
        .SRAM_LATENCY(SRAM_LATENCY),.SOURCE_KIND(0),.INIT_FILE(INPUT_FILE),.FC2_WEIGHTS_FILE(FC2_WEIGHTS_FILE)
    ) input_sram_inst (
        .clk(clk),.rst(pipe_reset),.req_valid(input_req),.req_addr(input_addr),.req_meta(input_request_meta),
        .row_valid(input_sram_valid),.row_data(input_sram_data),.row_meta(input_sram_meta)
    );
    fcnn_row_stage #(.LANES(LANES),.META_W(META_W)) weight_stage_inst (
        .clk(clk),.rst(pipe_reset),.in_valid(weight_sram_valid),.in_data(weight_sram_data),.in_meta(weight_sram_meta),
        .consume_row(consume_weight_row),.can_accept(),.stored_valid(weight_available),
        .stored_data(weight_stage_data),.stored_meta(weight_stage_meta)
    );
    fcnn_row_stage #(.LANES(LANES),.META_W(META_W)) input_stage_inst (
        .clk(clk),.rst(pipe_reset),.in_valid(input_sram_valid),.in_data(input_sram_data),.in_meta(input_sram_meta),
        .consume_row(consume_input_row),.can_accept(),.stored_valid(input_available),
        .stored_data(input_stage_data),.stored_meta(input_stage_meta)
    );
    // Step 3: Scheduler controls handshakes; Router owns arithmetic operand tags.
    fcnn_local_scheduler #(
        .N_INPUTS(N_INPUTS),.N_HIDDEN(N_HIDDEN),.N_OUTPUTS(N_OUTPUTS),.LANES(LANES)
    ) scheduler_inst (
        .clk(clk),.rst(rst),.run_init(run_init),.fc1_active(fc1_active),.fc2_active(fc2_active),
        .request_neuron(request_neuron),.request_fc1_row(request_fc1_row),.request_fc2_row(request_fc2_row),
        .weight_available(weight_available),.input_available(input_available),
        .compute_layer(compute_layer),.compute_row(compute_row),.product_ready(product_ready),.pp_wr_ready(pp_wr_ready),
        .term_last(term_last),.hidden_all_valid(hidden_all_valid),.activation_last_use(mul_issue && activation_last_term),
        .fc2_all_committed(fc2_all_committed),.final_ready(final_ready),.argmax_valid(argmax_valid),
        .request_layer(request_layer),.weight_req(weight_req),.input_req(input_req),
        .consume_weight_row(consume_weight_row),.consume_input_row(consume_input_row),
        .lane_idx(lane_idx),.mul_issue(mul_issue),.group_last(group_last),.rf_final_we(rf_final_we),
        .fc1_finished(fc1_finished),.fc2_finished(fc2_finished)
    );
    fcnn_operand_router #(
        .N_INPUTS(N_INPUTS),.N_HIDDEN(N_HIDDEN),.N_OUTPUTS(N_OUTPUTS),.LANES(LANES)
    ) router_inst (
        .weight_row(weight_stage_data),.input_row(input_stage_data),
        .weight_meta(weight_stage_meta),.input_meta(input_stage_meta),.lane_idx(lane_idx),
        .hidden_value(hidden_rd_data),.hidden_rd_idx(hidden_rd_idx),
        .mul_weight(mul_weight),.mul_input(mul_input),.term_valid(term_valid),
        .term_dest(term_dest),.term_last(term_last),.activation_last_term(activation_last_term)
    );
    // Step 4: the only FP16 multiplier; registered products enter two-bank PP.
    fcnn_fp16_multiplier multiplier_inst (.a(mul_weight),.b(mul_input),.result(mul_result));
    fcnn_product_register #(.DEST_W(DEST_W)) product_inst (
        .clk(clk),.rst(pipe_reset),.in_valid(mul_issue && term_valid),.in_ready(product_ready),
        .in_data(mul_result),.in_dest(term_dest),.in_last(term_last),.in_group_last(group_last),
        .out_valid(pp_wr_valid),.out_ready(pp_wr_ready),.out_data(pp_wr_data),.out_dest(pp_wr_dest),
        .out_last(pp_wr_last),.out_group_last(pp_wr_group_last)
    );
    fcnn_ping_pong_buffer #(.LANES(LANES),.DEST_W(DEST_W)) ping_pong_inst (
        .clk(clk),.rst(pipe_reset),.wr_valid(pp_wr_valid),.wr_ready(pp_wr_ready),
        .wr_data(pp_wr_data),.wr_dest(pp_wr_dest),.wr_last(pp_wr_last),.wr_group_last(pp_wr_group_last),
        .rd_valid(pp_rd_valid),.rd_ready(pp_rd_ready),.rd_data(pp_rd_data),.rd_dest(pp_rd_dest),.rd_last(pp_rd_last),
        .bank_full(),.bank_empty(),.bank_select()
    );
    // Step 5: the only FP16 adder; the backend mux schedules the separate bias.
    fcnn_fp16_adder adder_inst (.a(add_a),.b(add_b),.result(add_result));
    fcnn_bias_rom #(
        .N_HIDDEN(N_HIDDEN),.N_OUTPUTS(N_OUTPUTS),.FC1_BIAS_FILE(FC1_BIAS_FILE),.FC2_BIAS_FILE(FC2_BIAS_FILE)
    ) bias_inst (.fc1_neuron(bias_neuron),.fc1_bias(fc1_bias),.fc2_biases(fc2_biases));
    fcnn_accumulator_bank #(.N_HIDDEN(N_HIDDEN),.N_OUTPUTS(N_OUTPUTS)) accumulator_inst (
        .clk(clk),.rst(rst),.run_init(run_init),.layer_sel(fc2_active),
        .product_valid(pp_rd_valid),.product_ready(pp_rd_ready),.product_data(pp_rd_data),
        .product_dest(pp_rd_dest),.product_last(pp_rd_last),.bias_neuron(bias_neuron),
        .fc1_bias(fc1_bias),.fc2_biases(fc2_biases),.add_a(add_a),.add_b(add_b),.add_result(add_result),
        .add_commit(add_commit),.fc1_final_valid(fc1_final_valid),.fc1_final_value(fc1_final_value),
        .fc1_final_idx(fc1_final_idx),.fc2_all_committed(fc2_all_committed),.fc2_results(fc2_results)
    );
    // Step 6: ReLU -> reused RF -> balanced parallel argmax.
    fcnn_relu_fp16 relu_inst (.x(fc1_final_value),.y(relu_out));
    fcnn_activation_regfile #(.N_HIDDEN(N_HIDDEN),.N_OUTPUTS(N_OUTPUTS)) regfile_inst (
        .clk(clk),.rst(rst),.run_init(run_init),.hidden_wr_en(fc1_final_valid),
        .hidden_wr_idx(fc1_final_idx),.hidden_wr_data(relu_out),.hidden_rd_idx(hidden_rd_idx),.hidden_rd_data(hidden_rd_data),
        .hidden_all_valid(hidden_all_valid),.final_wr_en(rf_final_we),.final_wr_data(fc2_results),.final_ready(final_ready),.logits(logits)
    );
    fcnn_argmax #(.N_OUTPUTS(N_OUTPUTS)) argmax_inst (
        .logits(logits),.logits_valid(final_ready),.predicted_digit(predicted_digit),.argmax_valid(argmax_valid)
    );
    // Step 7: local contracts cover phase/tag errors and premature RF reuse.
    // synthesis translate_off
    always @(posedge clk) if (!pipe_reset) begin
        if (mul_issue && !term_valid)
            begin $display("[FAIL] DATAPATH invalid operand metadata or padding"); $finish; end
    end
    // synthesis translate_on
endmodule
`default_nettype wire

// Source: rtl/fcnn_fp16_adder.v
`default_nettype none
// fcnn_fp16_adder : هسته ترکیبی یک جمع FP16؛ بازخورد از انباشت‌گر انتخاب‌شده.
module fcnn_fp16_adder (
    input wire [15:0] a,
    input wire [15:0] b,
    output wire [15:0] result
);

    // =========================================================================
    // Step 1: Unpacking, Classification & Magnitude Compare (باز کردن بسته‌بندی، طبقه‌بندی و مقایسه اندازه)
    // =========================================================================
    wire sign_a;
    wire sign_b;
    wire [4:0] exp_a;
    wire [4:0] exp_b;
    wire [9:0] frac_a;
    wire [9:0] frac_b;

    wire a_is_zero;
    wire b_is_zero;
    wire a_is_sub;
    wire b_is_sub;
    wire a_is_inf;
    wire b_is_inf;
    wire a_is_nan;
    wire b_is_nan;

    wire [10:0] sig_a;
    wire [10:0] sig_b;
    wire [4:0] eff_exp_a;
    wire [4:0] eff_exp_b;
    wire eff_sub;
    wire a_lt_b;

    assign sign_a = a[15];
    assign sign_b = b[15];
    assign exp_a  = a[14:10];
    assign exp_b  = b[14:10];
    assign frac_a = a[9:0];
    assign frac_b = b[9:0];

    assign a_is_zero = (exp_a == 5'd0)  && (frac_a == 10'd0);
    assign b_is_zero = (exp_b == 5'd0)  && (frac_b == 10'd0);
    assign a_is_sub  = (exp_a == 5'd0)  && (frac_a != 10'd0);
    assign b_is_sub  = (exp_b == 5'd0)  && (frac_b != 10'd0);
    assign a_is_inf  = (exp_a == 5'h1F) && (frac_a == 10'd0);
    assign b_is_inf  = (exp_b == 5'h1F) && (frac_b == 10'd0);
    assign a_is_nan  = (exp_a == 5'h1F) && (frac_a != 10'd0);
    assign b_is_nan  = (exp_b == 5'h1F) && (frac_b != 10'd0);

    assign sig_a     = a_is_zero ? 11'd0 : {(~a_is_sub), frac_a};
    assign sig_b     = b_is_zero ? 11'd0 : {(~b_is_sub), frac_b};
    assign eff_exp_a = (a_is_sub || a_is_zero) ? 5'd1 : exp_a;
    assign eff_exp_b = (b_is_sub || b_is_zero) ? 5'd1 : exp_b;

    assign eff_sub = sign_a ^ sign_b;
    assign a_lt_b  = {exp_a, frac_a} < {exp_b, frac_b};

    // متغیرهای داخلی بلوک ترکیبی
    reg        sign_lg;
    reg [4:0]  exp_lg;
    reg [4:0]  exp_sm;
    reg [10:0] sig_lg;
    reg [10:0] sig_sm;

    reg [4:0]  exp_diff;
    reg [13:0] aligned_lg;
    reg [13:0] raw_sm;
    reg [13:0] shifted_sm;
    reg [13:0] sticky_mask;
    reg        sticky_sm;
    reg [13:0] aligned_sm;

    reg [14:0] sum_mant;
    reg [3:0]  lzc_sum;
    reg [4:0]  max_lshift;
    reg [3:0]  actual_lshift;
    reg [14:0] norm_mant;
    reg [5:0]  norm_exp;

    reg [10:0] main_sig;
    reg        guard_bit;
    reg        round_bit;
    reg        sticky_bit;
    reg        round_up;
    reg [11:0] rounded_sig;
    reg [5:0]  final_exp;
    reg [9:0]  final_frac;
    reg [15:0] result_reg;

    always @(*) begin
        // مقداردهی پیش‌فرض برای جلوگیری قطعی از ایجاد Latch
        sign_lg       = 1'b0;
        exp_lg        = 5'd0;
        exp_sm        = 5'd0;
        sig_lg        = 11'd0;
        sig_sm        = 11'd0;
        exp_diff      = 5'd0;
        aligned_lg    = 14'd0;
        raw_sm        = 14'd0;
        shifted_sm    = 14'd0;
        sticky_mask   = 14'd0;
        sticky_sm     = 1'b0;
        aligned_sm    = 14'd0;
        sum_mant      = 15'd0;
        lzc_sum       = 4'd0;
        max_lshift    = 5'd0;
        actual_lshift = 4'd0;
        norm_mant     = 15'd0;
        norm_exp      = 6'd0;
        main_sig      = 11'd0;
        guard_bit     = 1'b0;
        round_bit     = 1'b0;
        sticky_bit    = 1'b0;
        round_up      = 1'b0;
        rounded_sig   = 12'd0;
        final_exp     = 6'd0;
        final_frac    = 10'd0;
        result_reg    = 16'd0;

        // =====================================================================
        // Step 2: Operand Swapping & Mantissa Alignment (مرتب‌سازی عملوندها و تراز کردن مانتیس‌ها)
        // =====================================================================
        if (a_lt_b) begin
            sign_lg = sign_b;
            exp_lg  = eff_exp_b;
            exp_sm  = eff_exp_a;
            sig_lg  = sig_b;
            sig_sm  = sig_a;
        end else begin
            sign_lg = sign_a;
            exp_lg  = eff_exp_a;
            exp_sm  = eff_exp_b;
            sig_lg  = sig_a;
            sig_sm  = sig_b;
        end

        exp_diff   = exp_lg - exp_sm;
        aligned_lg = {sig_lg, 3'b000};
        raw_sm     = {sig_sm, 3'b000};

        if (exp_diff == 5'd0) begin
            shifted_sm  = raw_sm;
            sticky_mask = 14'd0;
            sticky_sm   = 1'b0;
            aligned_sm  = raw_sm;
        end else if (exp_diff >= 5'd14) begin
            shifted_sm  = 14'd0;
            sticky_mask = 14'h3FFF;
            sticky_sm   = |raw_sm;
            aligned_sm  = {13'd0, sticky_sm};
        end else begin
            shifted_sm  = raw_sm >> exp_diff;
            sticky_mask = 14'h3FFF >> (5'd14 - exp_diff);
            sticky_sm   = |(raw_sm & sticky_mask);
            aligned_sm  = {shifted_sm[13:1], shifted_sm[0] | sticky_sm};
        end

        // =====================================================================
        // Step 3: Mantissa Addition / Subtraction (جمع یا تفریق مانتیس‌های تراز شده)
        // =====================================================================
        if (eff_sub) begin
            sum_mant = {1'b0, aligned_lg} - {1'b0, aligned_sm};
        end else begin
            sum_mant = {1'b0, aligned_lg} + {1'b0, aligned_sm};
        end

        // =====================================================================
        // Step 4: Normalization & LZC (نرمال‌سازی، شمارش صفرهای پیشرو و مدیریت Gradual Underflow)
        // =====================================================================
        if (sum_mant[14]) begin
            norm_mant = {1'b0, sum_mant[14:2], sum_mant[1] | sum_mant[0]};
            norm_exp  = {1'b0, exp_lg} + 6'd1;
        end else begin
            casez (sum_mant[13:0])
                14'b1?????????????: lzc_sum = 4'd0;
                14'b01????????????: lzc_sum = 4'd1;
                14'b001???????????: lzc_sum = 4'd2;
                14'b0001??????????: lzc_sum = 4'd3;
                14'b00001?????????: lzc_sum = 4'd4;
                14'b000001????????: lzc_sum = 4'd5;
                14'b0000001???????: lzc_sum = 4'd6;
                14'b00000001??????: lzc_sum = 4'd7;
                14'b000000001?????: lzc_sum = 4'd8;
                14'b0000000001????: lzc_sum = 4'd9;
                14'b00000000001???: lzc_sum = 4'd10;
                14'b000000000001??: lzc_sum = 4'd11;
                14'b0000000000001?: lzc_sum = 4'd12;
                14'b00000000000001: lzc_sum = 4'd13;
                default:            lzc_sum = 4'd0;
            endcase

            max_lshift = exp_lg - 5'd1;

            if ({1'b0, lzc_sum} <= max_lshift) begin
                actual_lshift = lzc_sum;
                norm_mant     = sum_mant << actual_lshift;
                if (norm_mant[13]) begin
                    norm_exp = {1'b0, exp_lg - {1'b0, actual_lshift}};
                end else begin
                    norm_exp = 6'd0;
                end
            end else begin
                actual_lshift = max_lshift[3:0];
                norm_mant     = sum_mant << actual_lshift;
                norm_exp      = 6'd0;
            end
        end

        // =====================================================================
        // Step 5: RNE Rounding & Post-Normalization (گرد کردن به نزدیک‌ترین زوج)
        // =====================================================================
        main_sig    = norm_mant[13:3];
        guard_bit   = norm_mant[2];
        round_bit   = norm_mant[1];
        sticky_bit  = norm_mant[0];

        round_up    = guard_bit & (round_bit | sticky_bit | main_sig[0]);
        rounded_sig = {1'b0, main_sig} + {11'd0, round_up};

        if (rounded_sig[11]) begin
            final_exp  = norm_exp + 6'd1;
            final_frac = rounded_sig[10:1];
        end else begin
            if ((norm_exp == 6'd0) && rounded_sig[10]) begin
                final_exp  = 6'd1;
                final_frac = rounded_sig[9:0];
            end else begin
                final_exp  = norm_exp;
                final_frac = rounded_sig[9:0];
            end
        end

        // =====================================================================
        // Step 6: Exception Handling & Output Muxing (مدیریت استثناها و انتخاب خروجی نهایی)
        // =====================================================================
        if (a_is_nan || b_is_nan || (a_is_inf && b_is_inf && eff_sub)) begin
            // اولویت ۱: ورودی NaN یا جمع دو بی‌نهایت با علامت مخالف -> Canonical qNaN
            result_reg = 16'h7E00;
        end else if (a_is_inf) begin
            // اولویت ۲: بی‌نهایت ورودی اول
            result_reg = {sign_a, 5'h1F, 10'd0};
        end else if (b_is_inf) begin
            // اولویت ۲: بی‌نهایت ورودی دوم
            result_reg = {sign_b, 5'h1F, 10'd0};
        end else if (a_is_zero && b_is_zero) begin
            // اولویت ۳: هر دو ورودی صفر (-0 + -0 = -0، سایر حالات +0)
            result_reg = {sign_a & sign_b, 15'd0};
        end else if (a_is_zero) begin
            // اولویت ۴: فقط ورودی اول صفر است
            result_reg = b;
        end else if (b_is_zero) begin
            // اولویت ۴: فقط ورودی دوم صفر است
            result_reg = a;
        end else if (sum_mant == 15'd0) begin
            // اولویت ۵: حذف کامل در تفریق دو عدد هم‌اندازه -> +0 در مد RNE
            result_reg = 16'h0000;
        end else if (final_exp >= 6'd31) begin
            // اولویت ۶: سرریز نما به بی‌نهایت علامت‌دار
            result_reg = {sign_lg, 5'h1F, 10'd0};
        end else if ((final_exp == 6'd0) && (final_frac == 10'd0)) begin
            // اولویت ۷: صفر ناشی از Underflow
            result_reg = {sign_lg, 15'd0};
        end else begin
            // اولویت ۸: خروجی نرمال یا Subnormal معتبر
            result_reg = {sign_lg, final_exp[4:0], final_frac};
        end
    end

    assign result = result_reg;

endmodule
`default_nettype wire

// Source: rtl/fcnn_fp16_multiplier.v
`default_nettype none
// fcnn_fp16_multiplier : هسته ترکیبی یک ضرب IEEE-754 binary16 بدون تکثیر.
module fcnn_fp16_multiplier (
    input wire [15:0] a,
    input wire [15:0] b,
    output wire [15:0] result
);

    // =========================================================================
    // Step 1: Unpacking & Classification (باز کردن بسته‌بندی ورودی‌ها و تشخیص حالات خاص)
    // =========================================================================
    wire sign_a;
    wire sign_b;
    wire sign_res;
    wire [4:0] exp_a;
    wire [4:0] exp_b;
    wire [9:0] frac_a;
    wire [9:0] frac_b;

    wire a_is_zero;
    wire b_is_zero;
    wire a_is_sub;
    wire b_is_sub;
    wire a_is_inf;
    wire b_is_inf;
    wire a_is_nan;
    wire b_is_nan;

    wire [10:0] sig_a;
    wire [10:0] sig_b;
    wire [4:0] eff_exp_a;
    wire [4:0] eff_exp_b;

    assign sign_a   = a[15];
    assign sign_b   = b[15];
    assign sign_res = sign_a ^ sign_b;

    assign exp_a  = a[14:10];
    assign exp_b  = b[14:10];
    assign frac_a = a[9:0];
    assign frac_b = b[9:0];

    assign a_is_zero = (exp_a == 5'd0)  && (frac_a == 10'd0);
    assign b_is_zero = (exp_b == 5'd0)  && (frac_b == 10'd0);
    assign a_is_sub  = (exp_a == 5'd0)  && (frac_a != 10'd0);
    assign b_is_sub  = (exp_b == 5'd0)  && (frac_b != 10'd0);
    assign a_is_inf  = (exp_a == 5'h1F) && (frac_a == 10'd0);
    assign b_is_inf  = (exp_b == 5'h1F) && (frac_b == 10'd0);
    assign a_is_nan  = (exp_a == 5'h1F) && (frac_a != 10'd0);
    assign b_is_nan  = (exp_b == 5'h1F) && (frac_b != 10'd0);

    assign sig_a     = a_is_zero ? 11'd0 : {(~a_is_sub), frac_a};
    assign sig_b     = b_is_zero ? 11'd0 : {(~b_is_sub), frac_b};
    assign eff_exp_a = a_is_sub  ? 5'd1  : exp_a;
    assign eff_exp_b = b_is_sub  ? 5'd1  : exp_b;

    // =========================================================================
    // Step 2: Input Pre-Normalization (نرمال‌سازی عملوندهای ورودی Subnormal)
    // =========================================================================
    reg [3:0]  lzc_a;
    reg [3:0]  lzc_b;
    reg [10:0] norm_sig_a;
    reg [10:0] norm_sig_b;

    always @(*) begin
        lzc_a      = 4'd0;
        lzc_b      = 4'd0;
        norm_sig_a = sig_a;
        norm_sig_b = sig_b;

        if (a_is_sub) begin
            casez (frac_a)
                10'b1?????????: lzc_a = 4'd1;
                10'b01????????: lzc_a = 4'd2;
                10'b001???????: lzc_a = 4'd3;
                10'b0001??????: lzc_a = 4'd4;
                10'b00001?????: lzc_a = 4'd5;
                10'b000001????: lzc_a = 4'd6;
                10'b0000001???: lzc_a = 4'd7;
                10'b00000001??: lzc_a = 4'd8;
                10'b000000001?: lzc_a = 4'd9;
                10'b0000000001: lzc_a = 4'd10;
                default:        lzc_a = 4'd0;
            endcase
            norm_sig_a = sig_a << lzc_a;
        end

        if (b_is_sub) begin
            casez (frac_b)
                10'b1?????????: lzc_b = 4'd1;
                10'b01????????: lzc_b = 4'd2;
                10'b001???????: lzc_b = 4'd3;
                10'b0001??????: lzc_b = 4'd4;
                10'b00001?????: lzc_b = 4'd5;
                10'b000001????: lzc_b = 4'd6;
                10'b0000001???: lzc_b = 4'd7;
                10'b00000001??: lzc_b = 4'd8;
                10'b000000001?: lzc_b = 4'd9;
                10'b0000000001: lzc_b = 4'd10;
                default:        lzc_b = 4'd0;
            endcase
            norm_sig_b = sig_b << lzc_b;
        end
    end

    // =========================================================================
    // Step 3: Core Multiplication & Exponent Calculation (ضرب مانتیس ۱۱×۱۱ و محاسبه نمای اولیه)
    // =========================================================================
    wire [21:0] prod_raw;
    assign prod_raw = norm_sig_a * norm_sig_b;

    reg signed [7:0] exp_sum;
    reg [21:0]       prod_norm;
    reg [5:0]        rshift_amt;
    reg [21:0]       shifted_sig;
    reg [21:0]       sticky_mask;
    reg              guard_bit;
    reg              round_bit;
    reg              sticky_bit;
    reg [10:0]       main_sig;
    reg              round_up;
    reg [11:0]       rounded_sig;
    reg signed [7:0] final_exp;
    reg [9:0]        final_frac;
    reg [15:0]       result_reg;

    always @(*) begin
        // مقداردهی اولیه پیش‌فرض برای جلوگیری از ایجاد Latch ناخواسته
        exp_sum     = 8'sd0;
        prod_norm   = 22'd0;
        rshift_amt  = 6'd0;
        shifted_sig = 22'd0;
        sticky_mask = 22'd0;
        guard_bit   = 1'b0;
        round_bit   = 1'b0;
        sticky_bit  = 1'b0;
        main_sig    = 11'd0;
        round_up    = 1'b0;
        rounded_sig = 12'd0;
        final_exp   = 8'sd0;
        final_frac  = 10'd0;
        result_reg  = 16'd0;

        // تراز کردن بیت پیشرو روی بیت ۲۱ و محاسبه نمای اولیه با احتساب بایاس ۱۵
        if (prod_raw[21]) begin
            prod_norm = prod_raw;
            exp_sum   = $signed({3'b000, eff_exp_a}) + $signed({3'b000, eff_exp_b})
                      - 8'sd15
                      - $signed({4'b0000, lzc_a}) - $signed({4'b0000, lzc_b})
                      + 8'sd1;
        end else begin
            prod_norm = prod_raw << 1;
            exp_sum   = $signed({3'b000, eff_exp_a}) + $signed({3'b000, eff_exp_b})
                      - 8'sd15
                      - $signed({4'b0000, lzc_a}) - $signed({4'b0000, lzc_b});
        end

        // =====================================================================
        // Step 4: Alignment & GRS Extraction (مدیریت Gradual Underflow و استخراج بیت‌های GRS)
        // =====================================================================
        if (exp_sum > 8'sd0) begin
            shifted_sig = prod_norm;
            main_sig    = prod_norm[21:11];
            guard_bit   = prod_norm[10];
            round_bit   = prod_norm[9];
            sticky_bit  = |prod_norm[8:0];
        end else begin
            if ((8'sd1 - exp_sum) > 8'sd22) begin
                rshift_amt = 6'd23;
            end else begin
                rshift_amt = 6'd1 - exp_sum[5:0];
            end

            if (rshift_amt > 6'd22) begin
                shifted_sig = 22'd0;
                main_sig    = 11'd0;
                guard_bit   = 1'b0;
                round_bit   = 1'b0;
                sticky_bit  = |prod_norm;
            end else begin
                shifted_sig = prod_norm >> rshift_amt;
                main_sig    = shifted_sig[21:11];
                guard_bit   = shifted_sig[10];
                round_bit   = shifted_sig[9];
                sticky_mask = ~(22'h3FFFFF << (rshift_amt + 6'd9));
                sticky_bit  = |(prod_norm & sticky_mask);
            end
        end

        // =====================================================================
        // Step 5: RNE Rounding & Post-Normalization (گرد کردن به نزدیک‌ترین زوج)
        // =====================================================================
        round_up    = guard_bit & (round_bit | sticky_bit | main_sig[0]);
        rounded_sig = {1'b0, main_sig} + {11'd0, round_up};

        if (exp_sum > 8'sd0) begin
            if (rounded_sig[11]) begin
                final_exp  = exp_sum + 8'sd1;
                final_frac = rounded_sig[10:1];
            end else begin
                final_exp  = exp_sum;
                final_frac = rounded_sig[9:0];
            end
        end else begin
            if (rounded_sig[10]) begin
                final_exp  = 8'sd1;
                final_frac = rounded_sig[9:0];
            end else begin
                final_exp  = 8'sd0;
                final_frac = rounded_sig[9:0];
            end
        end

        // =====================================================================
        // Step 6: Exception Handling & Output Muxing (مدیریت استثناها و انتخاب خروجی نهایی)
        // =====================================================================
        if (a_is_nan || b_is_nan || (a_is_zero && b_is_inf) || (a_is_inf && b_is_zero)) begin
            // اولویت ۱: Canonical qNaN
            result_reg = 16'h7E00;
        end else if (a_is_inf || b_is_inf) begin
            // اولویت ۲: بی‌نهایت ورودی
            result_reg = {sign_res, 5'h1F, 10'd0};
        end else if (a_is_zero || b_is_zero) begin
            // اولویت ۳: صفر ورودی با حفظ علامت
            result_reg = {sign_res, 15'd0};
        end else if (final_exp >= 8'sd31) begin
            // اولویت ۴: سرریز نما (Overflow به بی‌نهایت علامت‌دار در مد RNE)
            result_reg = {sign_res, 5'h1F, 10'd0};
        end else if ((final_exp == 8'sd0) && (final_frac == 10'd0)) begin
            // اولویت ۵: Underflow کامل به صفر علامت‌دار
            result_reg = {sign_res, 15'd0};
        end else begin
            // اولویت ۶: خروجی نرمال یا Subnormal معتبر
            result_reg = {sign_res, final_exp[4:0], final_frac};
        end
    end

    assign result = result_reg;

endmodule
`default_nettype wire

// Source: rtl/fcnn_local_scheduler.v
`default_nettype none
module fcnn_local_scheduler #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7
) (
    clk,
    rst,
    run_init,
    fc1_active,
    fc2_active,
    request_neuron,
    request_fc1_row,
    request_fc2_row,
    weight_available,
    input_available,
    compute_layer,
    compute_row,
    product_ready,
    pp_wr_ready,
    term_last,
    hidden_all_valid,
    activation_last_use,
    fc2_all_committed,
    final_ready,
    argmax_valid,
    request_layer,
    weight_req,
    input_req,
    consume_weight_row,
    consume_input_row,
    lane_idx,
    mul_issue,
    group_last,
    rf_final_we,
    fc1_finished,
    fc2_finished
);
    // Step 1: control progress, not duplicated address counters.
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer R1_W=(FC1_ROWS>1)?$clog2(FC1_ROWS):1;
    localparam integer R2_W=(FC2_ROWS>1)?$clog2(FC2_ROWS):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer LANE_W=(LANES>1)?$clog2(LANES):1;
    localparam integer WAIT_W=$clog2(2*LANES+4);
    // Fixed pipeline edges: product register + PP register + phase transition.
    localparam integer PHASE_EDGES=3;
    localparam integer FC1_TAIL=N_INPUTS-(FC1_ROWS-1)*LANES;
    localparam integer FC2_TAIL=N_HIDDEN*N_OUTPUTS-(FC2_ROWS-1)*LANES;

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire clk;
    input wire rst;
    input wire run_init;
    input wire fc1_active;
    input wire fc2_active;
    input wire [H_W-1:0] request_neuron;
    input wire [R1_W-1:0] request_fc1_row;
    input wire [R2_W-1:0] request_fc2_row;
    input wire weight_available;
    input wire input_available;
    input wire compute_layer;
    input wire [ROW_W-1:0] compute_row;
    input wire product_ready;
    input wire pp_wr_ready;
    input wire term_last;
    input wire hidden_all_valid;
    input wire activation_last_use;
    input wire fc2_all_committed;
    input wire final_ready;
    input wire argmax_valid;
    output wire request_layer;
    output wire weight_req;
    output wire input_req;
    output wire consume_weight_row;
    output wire consume_input_row;
    output wire [LANE_W-1:0] lane_idx;
    output wire mul_issue;
    output wire group_last;
    output wire rf_final_we;
    output wire fc1_finished;
    output wire fc2_finished;

    reg [WAIT_W-1:0] request_wait;
    reg fc1_requests_done, fc2_requests_done, hidden_reads_done;
    reg bias_issue_gap;
    reg [LANE_W-1:0] lane_reg;
    wire final_fc1_row=request_fc1_row==FC1_ROWS-1;
    wire final_fc1_request=final_fc1_row && request_neuron==N_HIDDEN-1;
    wire final_fc2_request=request_fc2_row==FC2_ROWS-1;
    // Short FC1 rows still reserve a full bank service window.
    wire [31:0] request_lanes=LANES;
    wire [31:0] compute_lanes=compute_layer ?
        ((compute_row==FC2_ROWS-1)?FC2_TAIL:LANES) :
        ((compute_row==FC1_ROWS-1)?FC1_TAIL:LANES);
    wire [31:0] fc2_start=request_fc2_row*LANES;
    wire [31:0] fc2_end=fc2_start+LANES;
    localparam integer FC2_MAIN=N_OUTPUTS*(N_HIDDEN-1);
    wire [31:0] tail_terms;
    generate
        if (N_HIDDEN==1) begin: g_all_tail
            assign tail_terms=LANES;
        end else begin: g_tail_count
            assign tail_terms=(fc2_end<=FC2_MAIN)?0:
                ((fc2_start>=FC2_MAIN)?LANES:fc2_end-FC2_MAIN);
        end
    endgenerate
    wire [31:0] next_wait_fc1=request_lanes+
        (final_fc1_request ? PHASE_EDGES+LANES : (final_fc1_row?1:0))-1;
    wire [31:0] next_wait_fc2=LANES+tail_terms-1;
    // Step 2: reserve responses at the exact consumption cadence.
    assign request_layer=fc1_requests_done;
    assign weight_req=(fc1_active || fc2_active) && request_wait==0 &&
        (!fc1_requests_done || !fc2_requests_done);
    assign input_req=weight_req && !request_layer;
    assign lane_idx=lane_reg;
    wire fc1_issue=fc1_active && !compute_layer && weight_available && input_available;
    wire fc2_issue=fc2_active && compute_layer && weight_available && hidden_all_valid;
    assign mul_issue=(fc1_issue || fc2_issue) && !bias_issue_gap && product_ready && pp_wr_ready;
    assign group_last=lane_reg==compute_lanes-1;
    assign consume_weight_row=mul_issue && group_last;
    assign consume_input_row=consume_weight_row && !compute_layer;
    // Step 3: completion derives from committed values and last activation read.
    assign fc1_finished=hidden_all_valid;
    assign rf_final_we=fc2_active && fc2_all_committed && hidden_reads_done && !final_ready;
    assign fc2_finished=final_ready && argmax_valid;
    always @(posedge clk) begin
        if (rst || run_init) begin
            request_wait<=0; fc1_requests_done<=0; fc2_requests_done<=0;
            lane_reg<=0; hidden_reads_done<=0; bias_issue_gap<=0;
        end else begin
            if (weight_req) begin
                if (!request_layer) begin
                    if (final_fc1_request) begin
                        fc1_requests_done<=1;
                        request_wait<=next_wait_fc1[WAIT_W-1:0];
                    end else request_wait<=next_wait_fc1[WAIT_W-1:0];
                end else begin
                    request_wait<=next_wait_fc2[WAIT_W-1:0];
                    if (final_fc2_request) fc2_requests_done<=1;
                end
            end else if (request_wait!=0) request_wait<=request_wait-1'b1;
            if (mul_issue) begin
                if (group_last) lane_reg<=0;
                else lane_reg<=lane_reg+1'b1;
            end
            bias_issue_gap<=mul_issue && compute_layer && term_last;
            if (activation_last_use) hidden_reads_done<=1;
            // Step 4: an unexpected stall invalidates the single-row calendar.
            // synthesis translate_off
            if ((fc1_issue || fc2_issue) && !bias_issue_gap && (!product_ready || !pp_wr_ready))
                begin $display("[FAIL] SCHEDULER unexpected arithmetic stall"); $finish; end
            // synthesis translate_on
        end
    end
endmodule
`default_nettype wire

// Source: rtl/fcnn_operand_router.v
`default_nettype none
module fcnn_operand_router #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7
) (
    weight_row,
    input_row,
    weight_meta,
    input_meta,
    lane_idx,
    hidden_value,
    hidden_rd_idx,
    mul_weight,
    mul_input,
    term_valid,
    term_dest,
    term_last,
    activation_last_term
);
    // Step 1: decode request metadata independently of the current request phase.
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer MAX_NEURONS=(N_HIDDEN>N_OUTPUTS)?N_HIDDEN:N_OUTPUTS;
    localparam integer DEST_W=(MAX_NEURONS>1)?$clog2(MAX_NEURONS):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer META_W=1+H_W+ROW_W;
    localparam integer LANE_W=(LANES>1)?$clog2(LANES):1;
    localparam integer FC2_MAIN=N_OUTPUTS*(N_HIDDEN-1);

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire [16*LANES-1:0] weight_row;
    input wire [16*LANES-1:0] input_row;
    input wire [META_W-1:0] weight_meta;
    input wire [META_W-1:0] input_meta;
    input wire [LANE_W-1:0] lane_idx;
    input wire [15:0] hidden_value;
    output wire [H_W-1:0] hidden_rd_idx;
    output wire [15:0] mul_weight;
    output wire [15:0] mul_input;
    output wire term_valid;
    output wire [DEST_W-1:0] term_dest;
    output wire term_last;
    output wire activation_last_term;

    wire layer=weight_meta[META_W-1];
    wire [ROW_W-1:0] row_num=weight_meta[ROW_W-1:0];
    wire [H_W-1:0] neuron=weight_meta[ROW_W+:H_W];
    wire [31:0] scalar_idx=row_num*LANES+lane_idx;
    wire [31:0] hidden_idx, dest_idx;
    wire fc2_last;
    // Step 2: all but the final hidden input, then final input across outputs.
    // This retains the original 10+2 row layout for 8 hidden / 10 outputs.
    generate
        if (N_HIDDEN>1) begin: g_main
            assign fc2_last=scalar_idx>=FC2_MAIN;
            assign hidden_idx=(scalar_idx<FC2_MAIN)?scalar_idx%(N_HIDDEN-1):N_HIDDEN-1;
            assign dest_idx=(scalar_idx<FC2_MAIN)?scalar_idx/(N_HIDDEN-1):scalar_idx-FC2_MAIN;
        end else begin: g_single_hidden
            assign fc2_last=1;
            assign hidden_idx=0;
            assign dest_idx=scalar_idx;
        end
    endgenerate
    // Step 3: the hidden address has no combinational dependence on hidden data.
    assign hidden_rd_idx=layer ? hidden_idx[H_W-1:0] : {H_W{1'b0}};
    assign mul_weight=(lane_idx<LANES)?weight_row[16*lane_idx+:16]:16'd0;
    assign mul_input=layer ? hidden_value : ((lane_idx<LANES)?input_row[16*lane_idx+:16]:16'd0);
    assign term_valid=(lane_idx<LANES) && (layer ?
        (scalar_idx<N_HIDDEN*N_OUTPUTS) :
        (weight_meta==input_meta && scalar_idx<N_INPUTS && neuron<N_HIDDEN));
    assign term_dest=layer ? dest_idx[DEST_W-1:0] : neuron;
    assign term_last=layer ? fc2_last : scalar_idx==N_INPUTS-1;
    assign activation_last_term=layer && scalar_idx==N_HIDDEN*N_OUTPUTS-1;
endmodule
`default_nettype wire

// Source: rtl/fcnn_ping_pong_buffer.v
`default_nettype none
module fcnn_ping_pong_buffer #(
    parameter integer LANES=7, DEST_W=4
) (
    input wire clk, input wire rst,
    input wire wr_valid, output wire wr_ready,
    input wire [15:0] wr_data, input wire [DEST_W-1:0] wr_dest,
    input wire wr_last, input wire wr_group_last,
    output wire rd_valid, input wire rd_ready,
    output wire [15:0] rd_data, output wire [DEST_W-1:0] rd_dest,
    output wire rd_last,
    output wire [1:0] bank_full, output wire [1:0] bank_empty,
    output wire bank_select
);
    // Step 1: two physical banks. Pointer width includes the full sentinel.
    localparam integer PTR_W=$clog2(LANES+1);
    localparam integer SLOT_W=(LANES>1)?$clog2(LANES):1;
    reg [15:0] data0[0:LANES-1], data1[0:LANES-1];
    reg [DEST_W-1:0] dest0[0:LANES-1], dest1[0:LANES-1];
    reg last0[0:LANES-1], last1[0:LANES-1];
    reg end0[0:LANES-1], end1[0:LANES-1];
    reg [PTR_W-1:0] wp0,wp1,rp0,rp1,count0,count1;
    reg sealed0,sealed1,write_bank,read_bank;
    // Step 2: seal prevents reopening even a partially filled undrained bank.
    assign wr_ready=write_bank ? (!sealed1 && wp1<LANES) : (!sealed0 && wp0<LANES);
    assign rd_valid=read_bank ? (sealed1 && count1!=0) : (sealed0 && count0!=0);
    assign rd_data=read_bank ? data1[rp1[SLOT_W-1:0]] : data0[rp0[SLOT_W-1:0]];
    assign rd_dest=read_bank ? dest1[rp1[SLOT_W-1:0]] : dest0[rp0[SLOT_W-1:0]];
    assign rd_last=read_bank ? last1[rp1[SLOT_W-1:0]] : last0[rp0[SLOT_W-1:0]];
    assign bank_full={sealed1 || wp1==LANES,sealed0 || wp0==LANES};
    assign bank_empty={count1==0,count0==0};
    assign bank_select=write_bank;
    wire push0=wr_valid && wr_ready && !write_bank;
    wire push1=wr_valid && wr_ready && write_bank;
    wire pop0=rd_valid && rd_ready && !read_bank;
    wire pop1=rd_valid && rd_ready && read_bank;
    always @(posedge clk) begin
        if (rst) begin
            wp0<=0;wp1<=0;rp0<=0;rp1<=0;count0<=0;count1<=0;
            sealed0<=0;sealed1<=0;write_bank<=0;read_bank<=0;
        end else begin
            // Step 3: write and seal a group (including a short final group).
            if (push0) begin
                data0[wp0[SLOT_W-1:0]]<=wr_data; dest0[wp0[SLOT_W-1:0]]<=wr_dest;
                last0[wp0[SLOT_W-1:0]]<=wr_last; end0[wp0[SLOT_W-1:0]]<=wr_group_last;
                if (wr_group_last) begin sealed0<=1;wp0<=0;write_bank<=1;end
                else wp0<=wp0+1'b1;
            end
            if (push1) begin
                data1[wp1[SLOT_W-1:0]]<=wr_data; dest1[wp1[SLOT_W-1:0]]<=wr_dest;
                last1[wp1[SLOT_W-1:0]]<=wr_last; end1[wp1[SLOT_W-1:0]]<=wr_group_last;
                if (wr_group_last) begin sealed1<=1;wp1<=0;write_bank<=0;end
                else wp1<=wp1+1'b1;
            end
            // Step 4: read only a completed bank; release on its group terminator.
            if (pop0) begin
                if (end0[rp0[SLOT_W-1:0]]) begin sealed0<=0;rp0<=0;read_bank<=1;end
                else rp0<=rp0+1'b1;
            end
            if (pop1) begin
                if (end1[rp1[SLOT_W-1:0]]) begin sealed1<=0;rp1<=0;read_bank<=0;end
                else rp1<=rp1+1'b1;
            end
            // Step 5: simultaneous push/pop has a net occupancy change of zero.
            if (push0 && !pop0) count0<=count0+1'b1;
            else if (pop0 && !push0) count0<=count0-1'b1;
            if (push1 && !pop1) count1<=count1+1'b1;
            else if (pop1 && !push1) count1<=count1-1'b1;
            // synthesis translate_off
            if ((push0 && wp0==LANES-1 && !wr_group_last) ||
                (push1 && wp1==LANES-1 && !wr_group_last))
                begin $display("[FAIL] PING_PONG missing group terminator"); $finish; end
            // synthesis translate_on
        end
    end
endmodule
`default_nettype wire

// Source: rtl/fcnn_product_register.v
`default_nettype none
module fcnn_product_register #(parameter integer DEST_W=4) (
    input wire clk, input wire rst,
    input wire in_valid, output wire in_ready,
    input wire [15:0] in_data, input wire [DEST_W-1:0] in_dest,
    input wire in_last, input wire in_group_last,
    output reg out_valid, input wire out_ready,
    output reg [15:0] out_data, output reg [DEST_W-1:0] out_dest,
    output reg out_last, output reg out_group_last
);
    // Step 1: one elastic payload register, including every sideband bit.
    assign in_ready=!out_valid || out_ready;
    // Step 2: replace on ready, clear valid on a pop without a replacement.
    always @(posedge clk) begin
        if (rst) begin
            out_valid<=0; out_data<=0; out_dest<=0; out_last<=0; out_group_last<=0;
        end else if (in_ready) begin
            out_valid<=in_valid;
            if (in_valid) begin
                out_data<=in_data; out_dest<=in_dest;
                out_last<=in_last; out_group_last<=in_group_last;
            end
        end
    end
endmodule
`default_nettype wire

// Source: rtl/fcnn_relu_fp16.v
`default_nettype none
module fcnn_relu_fp16 (input wire [15:0] x, output wire [15:0] y);
    // Step 1: canonicalize any NaN; map every non-NaN negative to positive zero.
    wire is_nan=(x[14:10]==5'h1f) && (x[9:0]!=0);
    assign y=is_nan ? 16'h7e00 : (x[15] ? 16'h0000 : x);
endmodule
`default_nettype wire

// Source: rtl/fcnn_row_sram.v
`default_nettype none
// Raw scalar memory model. SOURCE_KIND=0: image; SOURCE_KIND=1: weights.
module fcnn_row_sram #(
    parameter integer N_INPUTS=784, N_HIDDEN=8, N_OUTPUTS=10, LANES=7,
    parameter integer SRAM_LATENCY=7, SOURCE_KIND=1,
    parameter INIT_FILE="fc1_weights.mem", FC2_WEIGHTS_FILE="fc2_weights.mem"
) (
    clk,
    rst,
    req_valid,
    req_addr,
    req_meta,
    row_valid,
    row_data,
    row_meta
);
    // Step 1: layout and widths derive only from network parameters.
    localparam integer FC1_ROWS=(N_INPUTS+LANES-1)/LANES;
    localparam integer FC2_ROWS=(N_HIDDEN*N_OUTPUTS+LANES-1)/LANES;
    localparam integer DEPTH=(SOURCE_KIND==1) ? N_HIDDEN*FC1_ROWS+FC2_ROWS : FC1_ROWS;
    localparam integer ADDR_W=(DEPTH>1)?$clog2(DEPTH):1;
    localparam integer H_W=(N_HIDDEN>1)?$clog2(N_HIDDEN):1;
    localparam integer ROW_W=$clog2(((FC1_ROWS>FC2_ROWS)?FC1_ROWS:FC2_ROWS)+1);
    localparam integer META_W=1+H_W+ROW_W;
    localparam integer FC2_MAIN=N_OUTPUTS*(N_HIDDEN-1);

    // Port widths are declared after derived constants for ModelSim 2020.
    input wire clk;
    input wire rst;
    input wire req_valid;
    input wire [ADDR_W-1:0] req_addr;
    input wire [META_W-1:0] req_meta;
    output wire row_valid;
    output wire [16*LANES-1:0] row_data;
    output wire [META_W-1:0] row_meta;

    wire [16*LANES-1:0] selected_row;
    // Step 2: raw files stay 16-bit/neuron-major; rows are assembled inside SRAM.
    generate
        if (SOURCE_KIND==1) begin: g_weights
            reg [15:0] fc1_words [0:N_INPUTS*N_HIDDEN-1];
            reg [15:0] fc2_words [0:N_HIDDEN*N_OUTPUTS-1];
            initial begin
                $readmemh(INIT_FILE, fc1_words);
                $readmemh(FC2_WEIGHTS_FILE, fc2_words);
            end
            genvar lane;
            for (lane=0; lane<LANES; lane=lane+1) begin: g_lane
                wire [31:0] fc1_neuron=req_addr/FC1_ROWS;
                wire [31:0] input_idx=(req_addr%FC1_ROWS)*LANES+lane;
                wire [31:0] term_idx=(req_addr-N_HIDDEN*FC1_ROWS)*LANES+lane;
                wire [31:0] dest_idx, hidden_idx;
                if (N_HIDDEN>1) begin: g_main
                    assign dest_idx=(term_idx<FC2_MAIN)?term_idx/(N_HIDDEN-1):term_idx-FC2_MAIN;
                    assign hidden_idx=(term_idx<FC2_MAIN)?term_idx%(N_HIDDEN-1):N_HIDDEN-1;
                end else begin: g_single_hidden
                    assign dest_idx=term_idx;
                    assign hidden_idx=0;
                end
                assign selected_row[16*lane+:16] =
                    (req_addr<N_HIDDEN*FC1_ROWS) ?
                        ((input_idx<N_INPUTS)?fc1_words[fc1_neuron*N_INPUTS+input_idx]:16'd0) :
                        ((term_idx<N_HIDDEN*N_OUTPUTS)?fc2_words[dest_idx*N_HIDDEN+hidden_idx]:16'd0);
            end
        end else begin: g_image
            reg [15:0] image_words [0:N_INPUTS-1];
            initial $readmemh(INIT_FILE, image_words);
            genvar lane;
            for (lane=0; lane<LANES; lane=lane+1) begin: g_lane
                assign selected_row[16*lane+:16] = (req_addr*LANES+lane<N_INPUTS) ? image_words[req_addr*LANES+lane] : 16'd0;
            end
        end
    endgenerate
    // Step 3: a request sampled at E is sampled downstream at E+SRAM_LATENCY.
    // Pipeline outputs change after NBA at E+SRAM_LATENCY-1; the next receiver
    // samples them at E+SRAM_LATENCY. The TB checks this edge convention.
    reg [SRAM_LATENCY-1:0] valid_pipe;
    reg [META_W-1:0] meta_pipe [0:SRAM_LATENCY-1];
    reg [16*LANES-1:0] data_pipe [0:SRAM_LATENCY-1];
    integer i;
    always @(posedge clk) begin
        if (rst) begin
            valid_pipe<=0;
        end else begin
            valid_pipe[0]<=req_valid;
            if (req_valid) begin
                data_pipe[0]<=selected_row;
                meta_pipe[0]<=req_meta;
            end
            for (i=1;i<SRAM_LATENCY;i=i+1) begin
                valid_pipe[i]<=valid_pipe[i-1];
                if (valid_pipe[i-1]) begin
                    data_pipe[i]<=data_pipe[i-1];
                    meta_pipe[i]<=meta_pipe[i-1];
                end
            end
            // synthesis translate_off
            if (req_valid && req_addr>=DEPTH)
                begin $display("[FAIL] SRAM invalid address=%0d depth=%0d",req_addr,DEPTH); $finish; end
            // synthesis translate_on
        end
    end
    assign row_valid=valid_pipe[SRAM_LATENCY-1];
    assign row_data=data_pipe[SRAM_LATENCY-1];
    assign row_meta=meta_pipe[SRAM_LATENCY-1];
endmodule
`default_nettype wire

// Source: rtl/fcnn_row_stage.v
`default_nettype none
module fcnn_row_stage #(
    parameter integer LANES=7, META_W=12
) (
    input wire clk, input wire rst,
    input wire in_valid, input wire [16*LANES-1:0] in_data,
    input wire [META_W-1:0] in_meta, input wire consume_row,
    output wire can_accept, output reg stored_valid,
    output reg [16*LANES-1:0] stored_data, output reg [META_W-1:0] stored_meta
);
    // Step 1: one row only; same-edge replacement does not allocate extra storage.
    assign can_accept=!stored_valid || consume_row;
    // Step 2: reset, accept/replace, consume, otherwise hold.
    always @(posedge clk) begin
        if (rst) begin
            stored_valid<=0; stored_data<=0; stored_meta<=0;
        end else begin
            if (in_valid && can_accept) begin
                stored_valid<=1; stored_data<=in_data; stored_meta<=in_meta;
            end else if (consume_row) stored_valid<=0;
            // Step 3: diagnose a calendar error rather than silently losing data.
            // synthesis translate_off
            if (in_valid && !can_accept)
                begin $display("[FAIL] ROW_STAGE overwrite"); $finish; end
            if (consume_row && !stored_valid)
                begin $display("[FAIL] ROW_STAGE empty consume"); $finish; end
            // synthesis translate_on
        end
    end
endmodule
`default_nettype wire

// Source: rtl/fcnn_top.v
`default_nettype none
// Step 1: the public configuration boundary. All user choices enter here.
module fcnn_top #(
    parameter integer N_INPUTS = 784,
    parameter integer N_HIDDEN = 8,
    parameter integer N_OUTPUTS = 10,
    parameter integer LANES = 7,
    parameter integer SRAM_LATENCY = 7,
    parameter FC1_WEIGHTS_FILE = "fc1_weights.mem",
    parameter FC2_WEIGHTS_FILE = "fc2_weights.mem",
    parameter INPUT_FILE = "test_image.mem",
    parameter FC1_BIAS_FILE = "fc1_bias.mem",
    parameter FC2_BIAS_FILE = "fc2_bias.mem"
) (
    input wire clk, input wire rst, input wire start,
    output wire busy, output wire done,
    output wire [16*N_OUTPUTS-1:0] logits,
    output wire [((N_OUTPUTS>1)?$clog2(N_OUTPUTS):1)-1:0] predicted_digit
);
    // Step 2: control/status only; no arithmetic or storage in Top.
    wire run_init, fc1_active, fc2_active, fc1_finished, fc2_finished;
    fcnn_controller controller_inst (
        .clk(clk), .rst(rst), .start(start),
        .fc1_finished(fc1_finished), .fc2_finished(fc2_finished),
        .run_init(run_init), .fc1_active(fc1_active), .fc2_active(fc2_active),
        .busy(busy), .done(done)
    );
    // Step 3: propagate every public setting by name.
    fcnn_datapath #(
        .N_INPUTS(N_INPUTS), .N_HIDDEN(N_HIDDEN), .N_OUTPUTS(N_OUTPUTS),
        .LANES(LANES), .SRAM_LATENCY(SRAM_LATENCY),
        .FC1_WEIGHTS_FILE(FC1_WEIGHTS_FILE), .FC2_WEIGHTS_FILE(FC2_WEIGHTS_FILE),
        .INPUT_FILE(INPUT_FILE), .FC1_BIAS_FILE(FC1_BIAS_FILE), .FC2_BIAS_FILE(FC2_BIAS_FILE)
    ) datapath_inst (
        .clk(clk), .rst(rst), .run_init(run_init),
        .fc1_active(fc1_active), .fc2_active(fc2_active),
        .fc1_finished(fc1_finished), .fc2_finished(fc2_finished),
        .logits(logits), .predicted_digit(predicted_digit)
    );
    // Step 4: configuration errors are explicit simulation failures.
    // synthesis translate_off
    initial begin
        if (N_INPUTS<1 || N_HIDDEN<1 || N_OUTPUTS<1 || LANES<1 || SRAM_LATENCY<1)
            begin $display("[FAIL] CONFIG positive dimensions/latency required"); $finish; end
    end
    // synthesis translate_on
endmodule
`default_nettype wire

