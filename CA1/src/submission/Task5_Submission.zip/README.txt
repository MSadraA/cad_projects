Generated Task-5 view of the maintained project.
Compile 05_code.v alone as the RTL source.
All numerical operations are binary16 RNE; bias is added last.
The PNG images accompany the actual RTL.
Full verification evidence is in the main project package.
