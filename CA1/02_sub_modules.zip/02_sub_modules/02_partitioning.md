<div dir="rtl" align="right">

# `02_partitioning.md` — تقسیم‌بندی ماژول‌ها، هدرها و دیاگرام اتصالات شتاب‌دهنده FCNN

**درس:** طراحی کامپیوتری سیستم‌های دیجیتال (CAD)  
**تسک:** ۲ — افراز معماری (Partitioning)، تعریف Module Headerها و نمودار اتصالات  
**زبان هدف:** Verilog-2005 / **شبیه‌ساز:** ModelSim  

---

## ۱. هدف و دامنه تسک دوم

در این سند، معماری شتاب‌دهنده FCNN به زیرماژول‌های مجزا و استاندارد افراز شده است تا بهینه بودن جریان داده، رعایت محدودیت منابع (تک ضرب‌کننده و تک جمع‌کننده FP16) و مدیریت صحیح حافظه‌های ۷ سیکلی تضمین گردد. خروجی‌های این مرحله عبارت‌اند از:
1. تعیین سلسله‌مراتب و مسئولیت دقیق **۱۷ ماژول** تشکیل‌دهنده سیستم.
2. تعریف جدول کامل پورت‌ها (نام، جهت، عرض بیت و نقش عملکردی).
3. ارائه کدهای استاندارد `Module Header` به زبان Verilog-2005 (بدون منطق داخلی).
4. نمایش دیاگرام اتصالات سطح بالا و مسیر داده/کنترل داخلی.

---

## ۲. خلاصه قیود معماری در افراز ماژول‌ها

| موضوع | مشخصات طراحی در افراز ماژول‌ها |
| :--- | :--- |
| **ساختار شبکه** | شبکه `784 -> 8 -> ReLU -> 10` با فرمت داده `IEEE-754 binary16 (FP16)` |
| **منابع محاسباتی** | دقیقاً **یک** نمونه از `fcnn_fp16_multiplier` و **یک** نمونه از `fcnn_fp16_adder` در کل سلسله‌مراتب |
| **حافظه‌های ردیفی** | ۲ نمونه از `fcnn_row_sram` (حافظه وزن با ۹۰۸ ردیف و حافظه ورودی با ۱۱۲ ردیف ۱۱۲ بیتی) با تأخیر ثابت ۷ سیکل |
| **ثبات‌های نگهداری ردیف** | ۲ نمونه از `fcnn_row_stage` برای نگهداری ایمن ردیف‌های ۷ کلمه‌ای واکشی‌شده از SRAM |
| **حافظه‌های میانی و خروجی** | یک `fcnn_ping_pong_buffer` دو بانکه، یک `fcnn_accumulator_bank` (شامل ۱ انباشتگر FC1 و ۱۰ انباشتگر FC2) و یک `fcnn_activation_regfile` ده خانه‌ای |
| **ساختار کنترل** | کنترلر سطح بالا (`fcnn_controller`) با ۴ حالت اصلی و زمان‌بند محلی (`fcnn_local_scheduler`) در داخل مسیر داده |

---

## ۳. سلسله‌مراتب و فهرست ماژول‌های سیستم

![اتصال سطح بالا](diagrams/top_partition.png)

معماری در سه لایه سلسله‌مراتبی سازمان‌دهی شده است:
- **لایه اول (`fcnn_top`):** رابط خارجی شتاب‌دهنده که یک نمونه از `fcnn_controller` و یک نمونه از `fcnn_datapath` را به یکدیگر متصل می‌کند.
- **لایه دوم (`fcnn_controller` و `fcnn_datapath`):** کنترلر سطح بالا مدیریت حالت‌های `IDLE`، `FC1`، `FC2` و `DONE` را بر عهده دارد و `Datapath` میزبان تمامی زیرماژول‌های محاسباتی، حافظه‌ای و مسیریابی است.
- **لایه سوم (زیرماژول‌های داخلی `fcnn_datapath`):** شامل ۱۴ ماژول تخصصی که جدول تعداد نمونه‌ها و وظایف آن‌ها در ادامه آمده است:

| نام ماژول | تعداد نمونه | مسئولیت در معماری |
| :--- | :---: | :--- |
| `fcnn_top` | ۱ | ماژول سطح بالا و مدیریت سیگنال‌های دست‌تکانی محیطی |
| `fcnn_controller` | ۱ | ماشین حالت متناهی (FSM) سطح بالا با ۴ وضعیت |
| `fcnn_datapath` | ۱ | یکپارچه‌سازی مسیر داده، حافظه‌ها و کنترلر محلی |
| `fcnn_row_sram` | ۲ | حافظه ردیفی ۱۱۲ بیتی با تأخیر ۷ سیکل (یک نمونه وزن با عمق ۹۰۸ و یک نمونه ورودی با عمق ۱۱۲) |
| `fcnn_row_stage` | ۲ | رجیستر صفحه‌ای برای نگهداری ردیف ۱۱۲ بیتی دریافتی از SRAM تا اتمام مصرف هر ۷ خانه |
| `fcnn_address_generator` | ۱ | تولید آدرس‌ها و تگ‌های متادیتا برای حافظه‌های وزن و ورودی در لایه‌های FC1 و FC2 |
| `fcnn_local_scheduler` | ۱ | زمان‌بندی درخواست‌های SRAM، پیمایش laneها، کنترل پایپ‌لاین و تشخیص تکمیل لایه‌ها |
| `fcnn_operand_router` | ۱ | انتخاب جفت عملوندهای ضرب، استخراج اندیس انباشتگر مقصد (`dest`) و نشانگر `last` |
| `fcnn_fp16_multiplier` | ۱ | هسته ترکیبی ضرب‌کننده ممیز شناور نیم‌دقت (تنها ضرب‌کننده مدار) |
| `fcnn_product_register` | ۱ | رجیستر پایپ‌لاین برای ثبت هم‌زمان خروجی ضرب و سیگنال‌های کنترلی (`dest`, `last`, `flush`) |
| `fcnn_ping_pong_buffer` | ۱ | بافر دو بانکه ۷ خانه‌ای بین ضرب‌کننده و جمع‌کننده با پشتیبانی از خواندن Cut-Through |
| `fcnn_fp16_adder` | ۱ | هسته ترکیبی جمع‌کننده ممیز شناور نیم‌دقت (تنها جمع‌کننده مدار) |
| `fcnn_accumulator_bank` | ۱ | مدیریت ۱ انباشتگر لایه FC1 و ۱۰ انباشتگر لایه FC2 به همراه پیش‌بارگذاری بایاس‌ها |
| `fcnn_activation_regfile` | ۱ | رجیسترفایل ۱۰ خانه‌ای برای نگهداری ۸ خروجی ReLU و سپس ثبت موازی ۱۰ خروجی نهایی |
| `fcnn_relu_fp16` | ۱ | واحد ترکیبی اعمال تابع فعال‌سازی یکسوساز خطی (ReLU) روی خروجی نورون‌های FC1 |
| `fcnn_argmax10` | ۱ | واحد مقایسه‌گر ترکیبی برای یافتن اندیس بیشینه در میان ۱۰ خروجی نهایی FP16 |
| `fcnn_bias_rom` | ۱ | حافظه ثابت برای تامین بلافاصله ۸ بایاس FC1 و ۱۰ بایاس FC2 |

---

## ۴. دیاگرام مسیر داده و قراردادهای ارتباطی بین ماژول‌ها

![نقشه اجزای داخلی Datapath](diagrams/datapath_partition_vertical.png)

### ۴.۱. ساختار برچسب متادیتا (`row_meta`)
برای حفظ همگامی بین درخواست‌های حافظه و داده‌هایی که ۷ سیکل بعد بازمی‌گردند، یک فیلد متادیتای ۱۲ بیتی به شکل زیر تعریف شده است که همراه با درخواست وارد خط لوله SRAM می‌شود:

</div>

<div dir="ltr" align="left">

```text
row_meta[11:0] = { layer[0], neuron[2:0], row[7:0] }
```

</div>

<div dir="rtl" align="right">

- بیت `layer`: مقدار `0` نشان‌دهنده لایه FC1 و مقدار `1` نشان‌دهنده لایه FC2 است.
- فیلد `neuron[2:0]`: در لایه FC1 شماره نورون جاری (`0..7`) را مشخص می‌کند (در لایه FC2 برابر صفر است).
- فیلد `row[7:0]`: در لایه FC1 شماره ردیف (`0..111`) و در لایه FC2 شماره ردیف محلی (`0..11`) را نشان می‌دهد.

### ۴.۲. نگاشت آدرس و چیدمان ۱۲ ردیفی لایه FC2 در `fcnn_operand_router`
- **لایه FC1:** آدرس وزن از رابطه `112 * fc1_neuron + fc1_row` (بازه `0..895`) و آدرس ورودی برابر `fc1_row` (بازه `0..111`) تولید می‌شود.
- **لایه FC2:** آدرس وزن از رابطه `896 + fc2_row` (بازه `896..907`) به دست می‌آید و جدول نگاشت عملوندها در `fcnn_operand_router` به شرح زیر است:

| ردیف محلی (`fc2_row`) | خانه‌های معتبر (`lane_idx`) | اندیس خواندن از RF (`hidden_rd_idx`) | مقصد انباشتگر (`term_dest`) | تعداد عملیات معتبر |
| :---: | :---: | :---: | :---: | :---: |
| `0..9` | `0..6` | `lane_idx` | `fc2_row` | $10 \times 7 = 70$ |
| `10` | `0..6` | `7` | `lane_idx` | $7$ |
| `11` | `0..2` | `7` | `7 + lane_idx` | $3$ |
| `11` | `3..6` | نامعتبر | نامعتبر | $0$ (Padding) |

### ۴.۳. خلاصه سیگنال‌های کنترلی بین `Controller` و `Datapath`

| مسیر سیگنال | نام پورت‌ها | نقش کنترلی |
| :--- | :--- | :--- |
| `Top -> Controller` | `clk, rst, start` | کلاک، ریست سنکرون و پالس شروع استنتاج |
| `Controller -> Datapath` | `run_init` | پالس یک‌سیکلی پاک‌سازی و آماده‌سازی در لحظه پذیرش `start` |
| `Controller -> Datapath` | `fc1_active, fc2_active, layer_sel` | تعیین فاز فعال محاسباتی مدار |
| `Datapath -> Controller` | `fc1_finished, fc2_finished` | اعلام اتمام قطعی ثبت داده‌های هر لایه به ماشین حالت اصلی |
| `Controller -> Top` | `busy, done` | اعلام وضعیت اشتغال مدار و پالس یک‌سیکلی پایان کار |
| `Datapath -> Top` | `logits[159:0], predicted_digit[3:0]` | بردار ده خروجی ۱۶ بیتی و اندیس ۴ بیتی رقم تشخیص‌داده‌شده |

---

## ۵. مشخصات کامل پورت‌های زیرماژول‌ها (Module Port Specifications)

### ۱. ماژول `fcnn_top`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سراسری حساس به لبه بالارونده |
| `input` | `rst` | 1 | ریست سنکرون فعال با یک (`Active-High`) |
| `input` | `start` | 1 | پالس یک‌سیکلی شروع عملیات در حالت `IDLE` |
| `output` | `busy` | 1 | نشانگر فعال بودن فرآیند استنتاج در لایه اول یا دوم |
| `output` | `done` | 1 | پالس یک‌سیکلی اعلام اعتبار خروجی‌ها |
| `output` | `logits` | 160 | ده خروجی نهایی FP16 (نورون $j$ در بیت‌های `[16*j +: 16]`) |
| `output` | `predicted_digit` | 4 | اندیس رقم پیش‌بینی‌شده توسط واحد Argmax (`0..9`) |

### ۲. ماژول `fcnn_controller`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون فعال با یک |
| `input` | `start` | 1 | درخواست شروع استنتاج |
| `input` | `fc1_finished` | 1 | تایید تکمیل کامل محاسبات و ثبت خروجی‌های لایه FC1 |
| `input` | `fc2_finished` | 1 | تایید تکمیل کامل محاسبات لایه FC2 و آماده شدن Argmax |
| `output` | `run_init` | 1 | پالس مقداردهی اولیه آغاز استنتاج جدید |
| `output` | `fc1_active` | 1 | فعال بودن وضعیت `FC1` در FSM |
| `output` | `fc2_active` | 1 | فعال بودن وضعیت `FC2` در FSM |
| `output` | `layer_sel` | 1 | انتخاب لایه (`0` برای FC1 و `1` برای FC2) |
| `output` | `busy` | 1 | بالا بودن در حین وضعیت‌های `FC1` و `FC2` |
| `output` | `done` | 1 | پالس خروجی در وضعیت `DONE` |

### ۳. ماژول `fcnn_datapath`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون |
| `input` | `run_init` | 1 | پاک‌سازی وضعیت‌های استنتاج قبلی |
| `input` | `fc1_active` | 1 | فعال بودن فاز لایه اول |
| `input` | `fc2_active` | 1 | فعال بودن فاز لایه دوم |
| `input` | `layer_sel` | 1 | شاخص لایه از سمت کنترلر |
| `output` | `fc1_finished` | 1 | اعلام پایان قطعی لایه اول به کنترلر |
| `output` | `fc2_finished` | 1 | اعلام پایان قطعی لایه دوم به کنترلر |
| `output` | `logits` | 160 | ده خروجی نهایی FP16 |
| `output` | `predicted_digit` | 4 | خروجی واحد Argmax |

### ۴. ماژول `fcnn_row_sram`
**پارامترها:** `parameter integer ADDR_W = 10, parameter integer DEPTH = 908, parameter INIT_FILE = "rows.mem"`

| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست خط لوله اعتبار درخواست‌های در پرواز |
| `input` | `req_valid` | 1 | اعتبار درخواست خواندن ردیف در سیکل جاری |
| `input` | `req_addr` | `ADDR_W` | آدرس ردیف مورد نظر |
| `input` | `req_meta` | 12 | متادیتای همراه درخواست |
| `output` | `row_valid` | 1 | اعتبار خروجی دقیقاً ۷ سیکل پس از درخواست |
| `output` | `row_data` | 112 | ردیف ۷ کلمه‌ای واکشی‌شده |
| `output` | `row_meta` | 12 | متادیتای همگام با ردیف خروجی |

### ۵. ماژول `fcnn_row_stage`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون |
| `input` | `in_valid` | 1 | ورود ردیف معتبر از خروجی SRAM |
| `input` | `in_data` | 112 | داده ۱۱۲ بیتی ردیف ورودی |
| `input` | `in_meta` | 12 | متادیتای ردیف ورودی |
| `input` | `consume_row` | 1 | اعلام مصرف شدن آخرین خانه معتبر ردیف جاری |
| `output` | `can_accept` | 1 | آمادگی پذیرش ردیف جدید (خالی بودن یا مصرف هم‌لبه) |
| `output` | `stored_valid` | 1 | معتبر بودن ردیف ذخیره‌شده فعلی |
| `output` | `stored_data` | 112 | داده ردیف ذخیره‌شده |
| `output` | `stored_meta` | 12 | متادیتای ردیف ذخیره‌شده |

### ۶. ماژول `fcnn_address_generator`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون |
| `input` | `run_init` | 1 | بازنشانی شمارنده‌های آدرس در شروع استنتاج |
| `input` | `layer_sel` | 1 | انتخاب فاز آدرس‌دهی (`0`: FC1، `1`: FC2) |
| `input` | `advance_row` | 1 | فرمان پیشروی به ردیف بعدی |
| `input` | `advance_neuron` | 1 | فرمان پیشروی به نورون بعدی در لایه FC1 |
| `output` | `fc1_neuron` | 3 | شماره نورون جاری لایه اول (`0..7`) |
| `output` | `fc1_row` | 7 | شماره ردیف جاری لایه اول (`0..111`) |
| `output` | `fc2_row` | 4 | شماره ردیف جاری لایه دوم (`0..11`) |
| `output` | `base_addr` | 10 | آدرس پایه وزن نورون FC1 (`112 * fc1_neuron`) |
| `output` | `weight_addr` | 10 | آدرس نهایی حافظه وزن (`0..907`) |
| `output` | `input_addr` | 7 | آدرس نهایی حافظه ورودی تصویر (`0..111`) |
| `output` | `weight_meta` | 12 | متادیتای تولیدشده برای درخواست وزن |
| `output` | `input_meta` | 12 | متادیتای تولیدشده برای درخواست ورودی |

### ۷. ماژول `fcnn_local_scheduler`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون |
| `input` | `run_init` | 1 | مقداردهی اولیه استنتاج |
| `input` | `fc1_active` | 1 | فعال بودن فاز FC1 |
| `input` | `fc2_active` | 1 | فعال بودن فاز FC2 |
| `input` | `weight_row_available` | 1 | وجود ردیف معتبر در `Weight Row Stage` |
| `input` | `input_row_available` | 1 | وجود ردیف معتبر در `Input Row Stage` |
| `input` | `weight_stage_can_accept` | 1 | ظرفیت پذیرش در `Weight Row Stage` |
| `input` | `input_stage_can_accept` | 1 | ظرفیت پذیرش در `Input Row Stage` |
| `input` | `pp_wr_ready` | 1 | آمادگی پورت نوشتن بافر پینگ‌پنگ |
| `input` | `product_pipe_ready` | 1 | آمادگی پذیرش در `fcnn_product_register` |
| `input` | `pp_rd_valid` | 1 | وجود داده معتبر برای خواندن در بافر پینگ‌پنگ |
| `input` | `fc1_final_commit` | 1 | ثبت شدن آخرین جمع یک نورون در لایه FC1 |
| `input` | `fc2_all_committed` | 1 | تکمیل شدن آخرین جمع تمامی ۱۰ نورون لایه FC2 |
| `input` | `hidden_all_valid` | 1 | آماده بودن هر ۸ خروجی ReLU در رجیسترفایل |
| `input` | `activation_last_use` | 1 | تایید انجام آخرین خواندن از فعال‌سازی‌های پنهان |
| `input` | `rf_outputs_ready` | 1 | ثبت شدن ۱۰ خروجی نهایی در رجیسترفایل |
| `input` | `argmax_valid` | 1 | معتبر بودن خروجی واحد Argmax |
| `output` | `weight_req` | 1 | صدور درخواست خواندن به `Weight SRAM` |
| `output` | `input_req` | 1 | صدور درخواست خواندن به `Input SRAM` |
| `output` | `advance_row` | 1 | پیشبرد شمارنده ردیف در مولد آدرس |
| `output` | `advance_neuron` | 1 | پیشبرد شمارنده نورون در مولد آدرس |
| `output` | `consume_weight_row` | 1 | آزادسازی ردیف فعلی وزن پس از مصرف آخرین خانه |
| `output` | `consume_input_row` | 1 | آزادسازی ردیف فعلی ورودی پس از مصرف آخرین خانه |
| `output` | `lane_idx` | 3 | انتخاب خانه جاری از ردیف ۷ تایی (`0..6`) |
| `output` | `mul_issue` | 1 | فرمان ثبت خروجی ضرب در `fcnn_product_register` |
| `output` | `group_last` | 1 | نشانگر آخرین عنصر معتبر در گروه جاری |
| `output` | `group_flush` | 1 | فرمان بستن گروه ناقص ۳ عضوی در پایان FC2 |
| `output` | `pp_rd_ready` | 1 | فرمان خواندن از بافر پینگ‌پنگ و ثبت جمع در انباشتگر |
| `output` | `fc1_acc_init` | 1 | سیگنال کمکی مقداردهی انباشتگر FC1 |
| `output` | `fc2_bias_preload` | 1 | فرمان پیش‌بارگذاری موازی ده بایاس لایه FC2 |
| `output` | `rf_final_we` | 1 | فرمان نوشتن موازی ۱۰ نتیجه نهایی در رجیسترفایل |
| `output` | `fc1_finished` | 1 | اعلام پایان کامل لایه اول |
| `output` | `fc2_finished` | 1 | اعلام پایان کامل لایه دوم |

### ۸. ماژول `fcnn_operand_router`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `layer_sel` | 1 | انتخاب لایه محاسباتی (`0`: FC1، `1`: FC2) |
| `input` | `weight_row` | 112 | ردیف ۷ کلمه‌ای وزن |
| `input` | `input_row` | 112 | ردیف ۷ کلمه‌ای ورودی تصویر |
| `input` | `weight_meta` | 12 | متادیتای ردیف وزن |
| `input` | `input_meta` | 12 | متادیتای ردیف ورودی |
| `input` | `lane_idx` | 3 | اندیس خانه انتخابی (`0..6`) |
| `input` | `hidden_value` | 16 | مقدار خوانده‌شده از رجیسترفایل برای لایه FC2 |
| `output` | `hidden_rd_idx` | 3 | آدرس خواندن فعال‌سازی پنهان از رجیسترفایل (`0..7`) |
| `output` | `mul_weight` | 16 | عملوند وزن ورودی به ضرب‌کننده FP16 |
| `output` | `mul_input` | 16 | عملوند دوم ورودی به ضرب‌کننده FP16 |
| `output` | `term_valid` | 1 | معتبر بودن جفت عملوند و خانه انتخابی |
| `output` | `term_dest` | 4 | اندیس انباشتگر مقصد (`0..7` در FC1 و `0..9` در FC2) |
| `output` | `term_last` | 1 | نشانگر آخرین ضرب مربوط به نورون مقصد |

### ۹. ماژول `fcnn_fp16_multiplier`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `a` | 16 | عملوند اول FP16 |
| `input` | `b` | 16 | عملوند دوم FP16 |
| `output` | `result` | 16 | حاصل‌ضرب ترکیبی FP16 با گردکردن استاندارد RNE |

### ۱۰. ماژول `fcnn_product_register`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون |
| `input` | `in_valid` | 1 | اعتبار داده ورودی از مرحله ضرب |
| `input` | `in_data` | 16 | مقدار حاصل‌ضرب FP16 |
| `input` | `in_dest` | 4 | مقصد انباشتگر |
| `input` | `in_last` | 1 | نشانگر آخرین عنصر نورون |
| `input` | `in_group_last` | 1 | نشانگر آخرین عنصر گروه |
| `input` | `in_flush` | 1 | نشانگر تخلیه گروه ناقص |
| `output` | `in_ready` | 1 | آمادگی پذیرش داده جدید |
| `output` | `out_valid` | 1 | اعتبار داده ثبت‌شده برای ارسال به بافر پینگ‌پنگ |
| `output` | `out_data` | 16 | مقدار حاصل‌ضرب ثبت‌شده |
| `output` | `out_dest` | 4 | مقصد ثبت‌شده |
| `output` | `out_last` | 1 | نشانگر آخرین عنصر ثبت‌شده |
| `output` | `out_group_last` | 1 | نشانگر پایان گروه ثبت‌شده |
| `output` | `out_flush` | 1 | نشانگر تخلیه ثبت‌شده |
| `input` | `out_ready` | 1 | سیگنال آمادگی از سمت بافر پینگ‌پنگ |

### ۱۱. ماژول `fcnn_ping_pong_buffer`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون |
| `input` | `wr_valid` | 1 | درخواست نوشتن محصول معتبر در بانک فعال نوشتن |
| `output` | `wr_ready` | 1 | آمادگی بانک نوشتن برای پذیرش داده |
| `input` | `wr_data` | 16 | داده محصول FP16 |
| `input` | `wr_dest` | 4 | اندیس انباشتگر مقصد |
| `input` | `wr_last` | 1 | نشانگر آخرین محصول نورون |
| `input` | `wr_group_last` | 1 | نشانگر آخرین عضو گروه ۷ تایی (یا ۳ تایی) |
| `input` | `wr_flush` | 1 | بستن فوری بانک برای گروه کوتاه انتهای FC2 |
| `output` | `rd_valid` | 1 | وجود داده معتبر برای خواندن توسط سمت جمع‌کننده |
| `input` | `rd_ready` | 1 | پذیرش و مصرف داده توسط سمت جمع‌کننده |
| `output` | `rd_data` | 16 | داده محصول خروجی به جمع‌کننده |
| `output` | `rd_dest` | 4 | مقصد انباشتگر خروجی |
| `output` | `rd_last` | 1 | نشانگر آخرین محصول نورون در خروجی |
| `output` | `bank_full` | 2 | وضعیت پر/بسته بودن هر یک از دو بانک |
| `output` | `bank_empty` | 2 | وضعیت خالی بودن هر یک از دو بانک |
| `output` | `bank_select` | 1 | نشانگر بانک انتخابی فعلی برای نوشتن |

### ۱۲. ماژول `fcnn_fp16_adder`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `a` | 16 | مقدار فعلی انباشتگر انتخاب‌شده (یا بایاس) |
| `input` | `b` | 16 | حاصل‌ضرب خوانده‌شده از بافر پینگ‌پنگ |
| `output` | `result` | 16 | حاصل‌جمع ترکیبی FP16 با گردکردن استاندارد RNE |

### ۱۳. ماژول `fcnn_accumulator_bank`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون |
| `input` | `run_init` | 1 | بازنشانی وضعیت انباشتگرها در شروع استنتاج |
| `input` | `fc1_acc_init` | 1 | مقداردهی صریح انباشتگر FC1 با بایاس |
| `input` | `fc1_bias` | 16 | مقدار بایاس نورون جاری FC1 |
| `input` | `fc2_bias_preload` | 1 | فرمان بارگذاری موازی ده بایاس FC2 در ده انباشتگر |
| `input` | `fc2_biases` | 160 | بردار ده بایاس ۱۶ بیتی لایه دوم |
| `input` | `layer_sel` | 1 | انتخاب لایه (`0`: FC1، `1`: FC2) |
| `input` | `add_dest` | 4 | اندیس انباشتگر مقصد |
| `input` | `add_result` | 16 | خروجی واحد جمع‌کننده FP16 |
| `input` | `add_commit` | 1 | فرمان ثبت خروجی جمع در انباشتگر مقصد |
| `input` | `add_last` | 1 | نشانگر آخرین جمع مربوط به نورون مقصد |
| `output` | `selected_acc` | 16 | مقدار انباشتگر انتخاب‌شده برای ورودی `a` جمع‌کننده |
| `output` | `fc1_final_valid` | 1 | اعلام تکمیل آخرین جمع نورون جاری در لایه FC1 |
| `output` | `fc1_final_value` | 16 | مقدار نهایی نورون FC1 پیش از اعمال ReLU |
| `output` | `fc1_final_idx` | 3 | اندیس نورون تکمیل‌شده در لایه FC1 (`0..7`) |
| `output` | `fc2_all_committed` | 1 | اعلام تکمیل آخرین جمع برای هر ۱۰ نورون لایه FC2 |
| `output` | `fc2_results` | 160 | بردار ده نتیجه ۱۶ بیتی انباشتگرهای لایه FC2 |

### ۱۴. ماژول `fcnn_activation_regfile`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `clk` | 1 | کلاک سیستم |
| `input` | `rst` | 1 | ریست سنکرون |
| `input` | `run_init` | 1 | پاک‌سازی فلگ‌های اعتبار در شروع استنتاج |
| `input` | `hidden_wr_en` | 1 | فرمان نوشتن خروجی ReLU نورون لایه اول |
| `input` | `hidden_wr_idx` | 3 | اندیس خانه مقصد برای فعال‌سازی پنهان (`0..7`) |
| `input` | `hidden_wr_data` | 16 | مقدار خروجی واحد ReLU |
| `input` | `hidden_rd_idx` | 3 | آدرس خواندن فعال‌سازی پنهان در فاز FC2 (`0..7`) |
| `output` | `hidden_rd_data` | 16 | مقدار فعال‌سازی پنهان خوانده‌شده |
| `output` | `hidden_all_valid` | 1 | تایید ثبت شدن هر ۸ مقدار فعال‌سازی لایه اول |
| `input` | `final_wr_en` | 1 | فرمان نوشتن موازی ۱۰ نتیجه نهایی لایه دوم |
| `input` | `final_wr_data` | 160 | بردار ۱۰ نتیجه نهایی از بانک انباشتگر |
| `output` | `final_ready` | 1 | تایید ثبت شدن ۱۰ خروجی نهایی در رجیسترفایل |
| `output` | `logits` | 160 | خروجی موازی ۱۰ مقدار نهایی FP16 |

### ۱۵. ماژول `fcnn_relu_fp16`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `x` | 16 | مقدار ورودی FP16 |
| `output` | `y` | 16 | خروجی ترکیبی $\max(x, 0)$ در فرمت FP16 |

### ۱۶. ماژول `fcnn_argmax10`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `logits` | 160 | بردار ده خروجی نهایی FP16 |
| `input` | `logits_valid` | 1 | اعتبار بردار ورودی |
| `output` | `predicted_digit` | 4 | اندیس بزرگ‌ترین مقدار (`0..9`) با اولویت اندیس کوچک‌تر |
| `output` | `argmax_valid` | 1 | اعتبار اندیس خروجی |

### ۱۷. ماژول `fcnn_bias_rom`
| جهت | نام پورت | عرض (بیت) | شرح وظیفه |
| :--- | :--- | :---: | :--- |
| `input` | `fc1_neuron` | 3 | اندیس نورون لایه FC1 (`0..7`) |
| `output` | `fc1_bias` | 16 | مقدار بایاس FP16 نورون انتخاب‌شده در لایه اول |
| `output` | `fc2_biases` | 160 | بردار موازی ده بایاس FP16 لایه دوم |

---

## ۶. کدهای هدر ماژول‌ها در Verilog-2005

کدهای کامل هدر تمامی ۱۷ ماژول در فایل ضمیمه `02_module_headers.v` و همچنین در ادامه آورده شده‌اند:

</div>

<div dir="ltr" align="left">

```verilog
module fcnn_top (
    input wire clk,
    input wire rst,
    input wire start,
    output wire busy,
    output wire done,
    output wire [159:0] logits,
    output wire [3:0] predicted_digit
);
endmodule

module fcnn_controller (
    input wire clk,
    input wire rst,
    input wire start,
    input wire fc1_finished,
    input wire fc2_finished,
    output wire run_init,
    output wire fc1_active,
    output wire fc2_active,
    output wire layer_sel,
    output wire busy,
    output wire done
);
endmodule

module fcnn_datapath (
    input wire clk,
    input wire rst,
    input wire run_init,
    input wire fc1_active,
    input wire fc2_active,
    input wire layer_sel,
    output wire fc1_finished,
    output wire fc2_finished,
    output wire [159:0] logits,
    output wire [3:0] predicted_digit
);
endmodule

module fcnn_row_sram #(
    parameter integer ADDR_W = 10,
    parameter integer DEPTH = 908,
    parameter INIT_FILE = "rows.mem"
)(
    input wire clk,
    input wire rst,
    input wire req_valid,
    input wire [ADDR_W-1:0] req_addr,
    input wire [11:0] req_meta,
    output wire row_valid,
    output wire [111:0] row_data,
    output wire [11:0] row_meta
);
endmodule

module fcnn_row_stage (
    input wire clk,
    input wire rst,
    input wire in_valid,
    input wire [111:0] in_data,
    input wire [11:0] in_meta,
    input wire consume_row,
    output wire can_accept,
    output wire stored_valid,
    output wire [111:0] stored_data,
    output wire [11:0] stored_meta
);
endmodule

module fcnn_address_generator (
    input wire clk,
    input wire rst,
    input wire run_init,
    input wire layer_sel,
    input wire advance_row,
    input wire advance_neuron,
    output wire [2:0] fc1_neuron,
    output wire [6:0] fc1_row,
    output wire [3:0] fc2_row,
    output wire [9:0] base_addr,
    output wire [9:0] weight_addr,
    output wire [6:0] input_addr,
    output wire [11:0] weight_meta,
    output wire [11:0] input_meta
);
endmodule

module fcnn_local_scheduler (
    input wire clk,
    input wire rst,
    input wire run_init,
    input wire fc1_active,
    input wire fc2_active,
    input wire weight_row_available,
    input wire input_row_available,
    input wire weight_stage_can_accept,
    input wire input_stage_can_accept,
    input wire pp_wr_ready,
    input wire product_pipe_ready,
    input wire pp_rd_valid,
    input wire fc1_final_commit,
    input wire fc2_all_committed,
    input wire hidden_all_valid,
    input wire activation_last_use,
    input wire rf_outputs_ready,
    input wire argmax_valid,
    output wire weight_req,
    output wire input_req,
    output wire advance_row,
    output wire advance_neuron,
    output wire consume_weight_row,
    output wire consume_input_row,
    output wire [2:0] lane_idx,
    output wire mul_issue,
    output wire group_last,
    output wire group_flush,
    output wire pp_rd_ready,
    output wire fc1_acc_init,
    output wire fc2_bias_preload,
    output wire rf_final_we,
    output wire fc1_finished,
    output wire fc2_finished
);
endmodule

module fcnn_operand_router (
    input wire layer_sel,
    input wire [111:0] weight_row,
    input wire [111:0] input_row,
    input wire [11:0] weight_meta,
    input wire [11:0] input_meta,
    input wire [2:0] lane_idx,
    input wire [15:0] hidden_value,
    output wire [2:0] hidden_rd_idx,
    output wire [15:0] mul_weight,
    output wire [15:0] mul_input,
    output wire term_valid,
    output wire [3:0] term_dest,
    output wire term_last
);
endmodule

module fcnn_fp16_multiplier (
    input wire [15:0] a,
    input wire [15:0] b,
    output wire [15:0] result
);
endmodule

module fcnn_product_register (
    input wire clk,
    input wire rst,
    input wire in_valid,
    input wire [15:0] in_data,
    input wire [3:0] in_dest,
    input wire in_last,
    input wire in_group_last,
    input wire in_flush,
    output wire in_ready,
    output wire out_valid,
    output wire [15:0] out_data,
    output wire [3:0] out_dest,
    output wire out_last,
    output wire out_group_last,
    output wire out_flush,
    input wire out_ready
);
endmodule

module fcnn_ping_pong_buffer (
    input wire clk,
    input wire rst,
    input wire wr_valid,
    output wire wr_ready,
    input wire [15:0] wr_data,
    input wire [3:0] wr_dest,
    input wire wr_last,
    input wire wr_group_last,
    input wire wr_flush,
    output wire rd_valid,
    input wire rd_ready,
    output wire [15:0] rd_data,
    output wire [3:0] rd_dest,
    output wire rd_last,
    output wire [1:0] bank_full,
    output wire [1:0] bank_empty,
    output wire bank_select
);
endmodule

module fcnn_fp16_adder (
    input wire [15:0] a,
    input wire [15:0] b,
    output wire [15:0] result
);
endmodule

module fcnn_accumulator_bank (
    input wire clk,
    input wire rst,
    input wire run_init,
    input wire fc1_acc_init,
    input wire [15:0] fc1_bias,
    input wire fc2_bias_preload,
    input wire [159:0] fc2_biases,
    input wire layer_sel,
    input wire [3:0] add_dest,
    input wire [15:0] add_result,
    input wire add_commit,
    input wire add_last,
    output wire [15:0] selected_acc,
    output wire fc1_final_valid,
    output wire [15:0] fc1_final_value,
    output wire [2:0] fc1_final_idx,
    output wire fc2_all_committed,
    output wire [159:0] fc2_results
);
endmodule

module fcnn_activation_regfile (
    input wire clk,
    input wire rst,
    input wire run_init,
    input wire hidden_wr_en,
    input wire [2:0] hidden_wr_idx,
    input wire [15:0] hidden_wr_data,
    input wire [2:0] hidden_rd_idx,
    output wire [15:0] hidden_rd_data,
    output wire hidden_all_valid,
    input wire final_wr_en,
    input wire [159:0] final_wr_data,
    output wire final_ready,
    output wire [159:0] logits
);
endmodule

module fcnn_relu_fp16 (
    input wire [15:0] x,
    output wire [15:0] y
);
endmodule

module fcnn_argmax10 (
    input wire [159:0] logits,
    input wire logits_valid,
    output wire [3:0] predicted_digit,
    output wire argmax_valid
);
endmodule

module fcnn_bias_rom (
    input wire [2:0] fc1_neuron,
    output wire [15:0] fc1_bias,
    output wire [159:0] fc2_biases
);
endmodule
```

</div>