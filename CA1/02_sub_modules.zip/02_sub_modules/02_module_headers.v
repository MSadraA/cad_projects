// CAD Project - Task 2: Module Headers (Verilog-2005)
// FCNN Hardware Accelerator Partitioning Interfaces

// 1. fcnn_top: Top-level accelerator wrapper connecting Controller and Datapath
module fcnn_top (
input wire clk,
input wire rst,
input wire start,
output wire busy,
output wire done,
output wire [159:0] logits,
output wire [3:0] predicted_digit
);
endmodule

// 2. fcnn_controller: High-level 4-state FSM (IDLE, FC1, FC2, DONE)
module fcnn_controller (
input wire clk,
input wire rst,
input wire start,
input wire fc1_finished,
input wire fc2_finished,
output wire run_init,
output wire fc1_active,
output wire fc2_active,
output wire layer_sel,
output wire busy,
output wire done
);
endmodule

// 3. fcnn_datapath: Complete datapath container and local scheduler host
module fcnn_datapath (
input wire clk,
input wire rst,
input wire run_init,
input wire fc1_active,
input wire fc2_active,
input wire layer_sel,
output wire fc1_finished,
output wire fc2_finished,
output wire [159:0] logits,
output wire [3:0] predicted_digit
);
endmodule

// 4. fcnn_row_sram: 112-bit row-oriented SRAM with fixed 7-cycle read latency
module fcnn_row_sram #(
parameter integer ADDR_W = 10,
parameter integer DEPTH = 908,
parameter INIT_FILE = "rows.mem"
)(
input wire clk,
input wire rst,
input wire req_valid,
input wire [ADDR_W-1:0] req_addr,
input wire [11:0] req_meta,
output wire row_valid,
output wire [111:0] row_data,
output wire [11:0] row_meta
);
endmodule

// 5. fcnn_row_stage: Single-row holding register stage for 7-word SRAM responses
module fcnn_row_stage (
input wire clk,
input wire rst,
input wire in_valid,
input wire [111:0] in_data,
input wire [11:0] in_meta,
input wire consume_row,
output wire can_accept,
output wire stored_valid,
output wire [111:0] stored_data,
output wire [11:0] stored_meta
);
endmodule

// 6. fcnn_address_generator: Row and neuron address/metadata generator for FC1 and FC2
module fcnn_address_generator (
input wire clk,
input wire rst,
input wire run_init,
input wire layer_sel,
input wire advance_row,
input wire advance_neuron,
output wire [2:0] fc1_neuron,
output wire [6:0] fc1_row,
output wire [3:0] fc2_row,
output wire [9:0] base_addr,
output wire [9:0] weight_addr,
output wire [6:0] input_addr,
output wire [11:0] weight_meta,
output wire [11:0] input_meta
);
endmodule

// 7. fcnn_local_scheduler: Cycle-level request, lane, pipeline, and commit scheduler
module fcnn_local_scheduler (
input wire clk,
input wire rst,
input wire run_init,
input wire fc1_active,
input wire fc2_active,
input wire weight_row_available,
input wire input_row_available,
input wire weight_stage_can_accept,
input wire input_stage_can_accept,
input wire pp_wr_ready,
input wire product_pipe_ready,
input wire pp_rd_valid,
input wire fc1_final_commit,
input wire fc2_all_committed,
input wire hidden_all_valid,
input wire activation_last_use,
input wire rf_outputs_ready,
input wire argmax_valid,
output wire weight_req,
output wire input_req,
output wire advance_row,
output wire advance_neuron,
output wire consume_weight_row,
output wire consume_input_row,
output wire [2:0] lane_idx,
output wire mul_issue,
output wire group_last,
output wire group_flush,
output wire pp_rd_ready,
output wire fc1_acc_init,
output wire fc2_bias_preload,
output wire rf_final_we,
output wire fc1_finished,
output wire fc2_finished
);
endmodule

// 8. fcnn_operand_router: Lane selector and destination/last tag router
module fcnn_operand_router (
input wire layer_sel,
input wire [111:0] weight_row,
input wire [111:0] input_row,
input wire [11:0] weight_meta,
input wire [11:0] input_meta,
input wire [2:0] lane_idx,
input wire [15:0] hidden_value,
output wire [2:0] hidden_rd_idx,
output wire [15:0] mul_weight,
output wire [15:0] mul_input,
output wire term_valid,
output wire [3:0] term_dest,
output wire term_last
);
endmodule

// 9. fcnn_fp16_multiplier: Single combinational IEEE-754 binary16 multiplier
module fcnn_fp16_multiplier (
input wire [15:0] a,
input wire [15:0] b,
output wire [15:0] result
);
endmodule

// 10. fcnn_product_register: Elastic pipeline register for product and sideband tags
module fcnn_product_register (
input wire clk,
input wire rst,
input wire in_valid,
input wire [15:0] in_data,
input wire [3:0] in_dest,
input wire in_last,
input wire in_group_last,
input wire in_flush,
output wire in_ready,
output wire out_valid,
output wire [15:0] out_data,
output wire [3:0] out_dest,
output wire out_last,
output wire out_group_last,
output wire out_flush,
input wire out_ready
);
endmodule

// 11. fcnn_ping_pong_buffer: Dual-bank 7-entry cut-through buffer with handshake
module fcnn_ping_pong_buffer (
input wire clk,
input wire rst,
input wire wr_valid,
output wire wr_ready,
input wire [15:0] wr_data,
input wire [3:0] wr_dest,
input wire wr_last,
input wire wr_group_last,
input wire wr_flush,
output wire rd_valid,
input wire rd_ready,
output wire [15:0] rd_data,
output wire [3:0] rd_dest,
output wire rd_last,
output wire [1:0] bank_full,
output wire [1:0] bank_empty,
output wire bank_select
);
endmodule

// 12. fcnn_fp16_adder: Single combinational IEEE-754 binary16 adder
module fcnn_fp16_adder (
input wire [15:0] a,
input wire [15:0] b,
output wire [15:0] result
);
endmodule

// 13. fcnn_accumulator_bank: 1 FC1 accumulator and 10 FC2 accumulators with bias preload
module fcnn_accumulator_bank (
input wire clk,
input wire rst,
input wire run_init,
input wire fc1_acc_init,
input wire [15:0] fc1_bias,
input wire fc2_bias_preload,
input wire [159:0] fc2_biases,
input wire layer_sel,
input wire [3:0] add_dest,
input wire [15:0] add_result,
input wire add_commit,
input wire add_last,
output wire [15:0] selected_acc,
output wire fc1_final_valid,
output wire [15:0] fc1_final_value,
output wire [2:0] fc1_final_idx,
output wire fc2_all_committed,
output wire [159:0] fc2_results
);
endmodule

// 14. fcnn_activation_regfile: 10-entry FP16 register file for hidden activations and final logits
module fcnn_activation_regfile (
input wire clk,
input wire rst,
input wire run_init,
input wire hidden_wr_en,
input wire [2:0] hidden_wr_idx,
input wire [15:0] hidden_wr_data,
input wire [2:0] hidden_rd_idx,
output wire [15:0] hidden_rd_data,
output wire hidden_all_valid,
input wire final_wr_en,
input wire [159:0] final_wr_data,
output wire final_ready,
output wire [159:0] logits
);
endmodule

// 15. fcnn_relu_fp16: Combinational FP16 ReLU activation unit
module fcnn_relu_fp16 (
input wire [15:0] x,
output wire [15:0] y
);
endmodule

// 16. fcnn_argmax10: 10-input combinational FP16 argmax with smallest-index tie-break
module fcnn_argmax10 (
input wire [159:0] logits,
input wire logits_valid,
output wire [3:0] predicted_digit,
output wire argmax_valid
);
endmodule

// 17. fcnn_bias_rom: Dedicated constant ROM for 8 FC1 biases and 10 FC2 biases
module fcnn_bias_rom (
input wire [2:0] fc1_neuron,
output wire [15:0] fc1_bias,
output wire [159:0] fc2_biases
);
endmodule